<?php
require_once('database_access.php');
require_once('manualDB.php');
?>