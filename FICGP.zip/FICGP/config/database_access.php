<?php
require_once 'idiorm.php';
ORM::configure('return_result_sets', true);
ORM::configure('mysql:host=localhost;dbname=evolution');
ORM::configure('username', 'administrator');
ORM::configure('password', 'iamgod@earth');
?>