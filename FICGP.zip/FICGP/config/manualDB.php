<?php
$servername = "localhost";
$username = "administrator";
$password = "iamgod@earth";
$dbname = "evolution";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    $status = base64_encode("Connection to database failed.");
    $target = "2";
    $kind = base64_encode("4");
    $padding = "#tab2";
    header('location: ../router.php?status=' . $status . '&target=' . $target . '&kind=' . $kind . '&padding=' . $padding);
}

?>