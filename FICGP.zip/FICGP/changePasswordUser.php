<?php
require_once('customScript/checkSession.php');
checkThisPage("changePasswordUser.php");
?>

<?php require_once('header/essentials.php'); ?>

<?php require_once('content/changePasswordUserContent.php'); ?>

<?php require_once('footer/footer.php'); ?>