<?php
require_once('customScript/checkSession.php');
checkThisPage("changePassword.php");
?>
<?php require_once('header/essentials.php'); ?>
<?php require_once('content/changePasswordContent.php'); ?>
<?php require_once('footer/footer.php'); ?>
