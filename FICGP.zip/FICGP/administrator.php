<?php
require_once('customScript/checkSession.php');
//checkThisPage("administrator.php");
?>
<?php require_once('header/essentials.php'); ?>
<?php require_once('content/administratorContent.php'); ?>
<?php require_once('footer/footer.php'); ?>