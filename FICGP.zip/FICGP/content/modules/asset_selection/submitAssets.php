<?php
	require_once('../../../config/masterDatabaseAccess.php');

	$count = $_POST["count"];
	$id_product_content = $_POST["id_product_content"];
	$templateName = $_POST["template_name"];

	$stringForData = "";
	$ids = "";
	$URL = "http://localhost/FICGP/content/modules/assets/";
	for($i=0;$i<$count;$i++){
		$asset = ORM::for_table('asset')->where('id', $_POST['form_element_'.$i])->find_one();

		if($asset->count() > 0){
			$ids .= $_POST['form_element_'.$i] . ';';
			if($asset->id_asset_type == "e27b227bb24d965bf86c640d23bcb105"){

				$myfile = fopen("../assets/".$asset->file, "r") or die("Unable to open file!");
				$readData = fread($myfile, filesize("../assets/".$asset->file));
				fclose($myfile);

				$readData = str_replace("'", "\'", $readData);
				$stringForData .= "var_" . ($i+1) ." = '" . $readData . "';";	
			}
			else{
				$stringForData .= "var_" . ($i+1) ." = '" . $URL . $asset->file . "';";		
			}
		}
		else{
		}
	}
	mkdir("../published_files/".$id_product_content);
	$newPath = "../published_files/".$id_product_content."/";
	$myfile1 = fopen($newPath."data.js", "w") or die("Unable to open file!");
    fwrite($myfile1,$stringForData,strlen($stringForData));
	fclose($myfile1);

	copy("../assets/".$templateName,$newPath.$id_product_content.".html");

	$product_content_assets_check = ORM::for_table('product_content_asset')->where('id_product_content', $id_product_content)->find_many();

	if($product_content_assets_check->count() > 0){
		header("location: ../published_files/".$id_product_content ."/".$id_product_content.".html");
	}
	else{
		$product_content_assets = ORM::for_table('product_content_asset')->create();
		$product_content_assets->id_product_content = $id_product_content;
		$product_content_assets->id_asset = $ids;
		$product_content_assets->save();

		echo $ids;
	}
?>