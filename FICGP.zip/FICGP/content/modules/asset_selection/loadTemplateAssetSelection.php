<?php
require_once('../../../config/masterDatabaseAccess.php');

if(isset($_GET["id"])){

	if($_GET["id"] != 0){

		$contentData = ORM::for_table('product_template')->raw_query("SELECT product_content.id,
			content_template.file
			FROM product_template
			INNER JOIN product_content
			ON product_content.id = product_template.id_product_content
			INNER JOIN content_template
			ON content_template.id = product_template.id_content_template
			WHERE product_content.id = '$_GET[id]'")->find_one();
		$numbers = $contentData->count();
		if ($numbers == 0) {

		}
		else{
			copy("../assets/$contentData->file", "../published_files/".$contentData->id.".html");
			$handle = fopen("../assets/$contentData->file", "r");
			if ($handle) {
				$dataToTake = "";
				while (($line = fgets($handle)) !== false) {
					if(strncmp($line,"<!--",4)==0){
						switch (substr($line, 4,3)) {
							case '001':{
								$dataToTake .= "001".",";
								break;
							}
							case '002':{
								$dataToTake .= "002".",";
								break;
							}
							case '003':{
								$dataToTake .= "003".",";
								break;
							}
							case '004':{
								$dataToTake .= "004".",";
								break;
							}
							case '005':{
								$dataToTake .= "005".",";
								break;
							}
						}
					}
					else{
						break;
					}
				}
				fclose($handle);
				$datas = explode(',', $dataToTake);
				$i=0;
				$flag = 0;
				$product_content_assets_checks = ORM::for_table('product_content_asset')->where('id_product_content', $_GET["id"])->find_many();

				if($product_content_assets_checks->count() > 0){
					foreach ($product_content_assets_checks as $product_content_assets_check) {
						$ids = $product_content_assets_check->id_asset;
						$allIds = explode(';', $ids);
						$flag = 1;
					}
				}	


				?>
				<form action="submitAssets.php" method="post">
					<?php
					foreach ($datas as $data) {	
						switch ($data) {
							case '001':{
								?>
								<fieldset style="margin:0px;">
									<legend>Image</legend>
									<select  style="width:100%" name="form_element_<?= $i ?>">
										<option value="none">Please Select One</option>
										<?php
										$assets = ORM::for_table('asset')->where('id_asset_type', 'ae73b2ae5d2eee85f1289aade1b1a839')->find_many();
										if($assets->count() > 0){
											$done = 0;
											foreach ($assets as $asset) {
												if($flag == 1 && $done == 0){
													foreach ($allIds as $id){
														if($id == $asset->id){
															?>
																<option value="<?= $asset->id ?>" selected><?= $asset->name ?></option>
															<?php
															$done = 1;
														}
													}
												}
												else{
													?>
													<option value="<?= $asset->id ?>"><?= $asset->name ?></option>
													<?php
												}
											}
										}					
										?>
									</select>
								</fieldset>
								<br>
								<?php
								$i++;
								break;
							}
							case '002':{
								?>
								<fieldset style="margin:0;">
									<legend>Document</legend>
									<select  style="width:100%" name="form_element_<?= $i ?>">
										<option value="none">Please Select One</option>
										<?php
										$assets = ORM::for_table('asset')->where('id_asset_type', 'e27b227bb24d965bf86c640d23bcb105')->find_many();
										if($assets->count() > 0){
											$done = 0;
											foreach ($assets as $asset) {
												if($flag == 1 && $done == 0){
													foreach ($allIds as $id){
														if($id == $asset->id){
															?>
																<option value="<?= $asset->id ?>" selected><?= $asset->name ?></option>
															<?php
															$done = 1;
														}
													}
												}
												else{
													?>
													<option value="<?= $asset->id ?>"><?= $asset->name ?></option>
													<?php
												}
											}
										}								
										?>
									</select>
								</fieldset>
								<br>
								<?php
								$i++;
								break;
							}
							case '003':{
								?>
								<fieldset style="margin:0;">
									<legend>Audio</legend>
									<select  style="width:100%" name="form_element_<?= $i ?>">
										<option value="none">Please Select One</option>
										<?php
										$assets = ORM::for_table('asset')->where('id_asset_type', '97d55158b65a2c24ebc5d73277456ed7')->find_many();
										if($assets->count() > 0){
											$done = 0;
											foreach ($assets as $asset) {
												if($flag == 1 && $done == 0){
													foreach ($allIds as $id){
														if($id == $asset->id){
															?>
																<option value="<?= $asset->id ?>" selected><?= $asset->name ?></option>
															<?php
															$done = 1;
														}
													}
												}
												else{
													?>
													<option value="<?= $asset->id ?>"><?= $asset->name ?></option>
													<?php
												}
											}
										}							
										?>
									</select>
								</fieldset>
								<br>
								<?php
								$i++;
								break;
							}
							case '004':{
								?>
								<fieldset style="margin:0;">
									<legend>Video</legend>
									<select  style="width:100%" name="form_element_<?= $i ?>">
										<option value="none">Please Select One</option>
										<?php
										$assets = ORM::for_table('asset')->where('id_asset_type', 'fd74f560eeffb166d53de18da036b3b5')->find_many();
										if($assets->count() > 0){
											$done = 0;
											foreach ($assets as $asset) {
												if($flag == 1 && $done == 0){
													foreach ($allIds as $id){
														if($id == $asset->id){
															?>
																<option value="<?= $asset->id ?>" selected><?= $asset->name ?></option>
															<?php
															$done = 1;
														}
													}
												}
												else{
													?>
													<option value="<?= $asset->id ?>"><?= $asset->name ?></option>
													<?php
												}
											}
										}							
										?>
									</select>
								</fieldset>
								<br>
								<?php
								$i++;
								break;
							}
						}
					}				
					?>
					<input type="hidden" name="id_product_content" value="<?= $contentData->id ?>">
					<input type="hidden" name="template_name" value="<?= $contentData->file ?>">
					<input type="hidden" name="count" value="<?= $i ?>">
					<hr>
					<input type="submit" value="Use This Data">
				</form>
				<?php				   
			} else {
			// error opening the file.
			} 
		}
	}
	else{
		echo "<h1>Please Select Proper Product Content Name</h1>";
	}
}
else{
	echo "<h1>Please Select Proper Product Content Name</h1>";
}
?>