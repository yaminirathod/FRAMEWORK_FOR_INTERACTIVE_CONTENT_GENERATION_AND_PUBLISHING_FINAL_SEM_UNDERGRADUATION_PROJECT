<?php
require_once('../../../config/masterDatabaseAccess.php');
$product_contents = ORM::for_table('product_content')->find_many();

?>
<html>
<head>
</head>
<body>

<select style="width:100%;" ONCHANGE="document.getElementById('selectionFrame').src = 'loadTemplateAssetSelection.php?id='+this.options[this.selectedIndex].value">
<option value="0">Please Select</option>
<?php
$numbers = $product_contents->count();
if($numbers > 0){
	foreach ($product_contents as $product_content) {
	?>
	<option value="<?= $product_content->id ?>"><?= $product_content->name ?></option>
	<?php
	}	
}
?>
</select>
<iframe id="selectionFrame" src="loadTemplateAssetSelection.php" style="width:100%;height:90%;border:none;"></iframe>
</body>
</html>