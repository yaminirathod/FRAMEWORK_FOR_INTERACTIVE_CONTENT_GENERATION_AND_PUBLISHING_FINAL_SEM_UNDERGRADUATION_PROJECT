<?php
if (session_id() == "") session_start(); // Initialize Session data
ob_start(); // Turn on output buffering
?>
<?php include_once "ewcfg10.php" ?>
<?php include_once "ewmysql10.php" ?>
<?php include_once "phpfn10.php" ?>
<?php include_once "assetinfo.php" ?>
<?php include_once "userfn10.php" ?>
<?php

//
// Page class
//

$asset_delete = NULL; // Initialize page object first

class casset_delete extends casset {

	// Page ID
	var $PageID = 'delete';

	// Project ID
	var $ProjectID = "{3F4DCFAD-76CE-4EF9-8198-C7C0BA2B5B2C}";

	// Table name
	var $TableName = 'asset';

	// Page object name
	var $PageObjName = 'asset_delete';

	// Page name
	function PageName() {
		return ew_CurrentPage();
	}

	// Page URL
	function PageUrl() {
		$PageUrl = ew_CurrentPage() . "?";
		if ($this->UseTokenInUrl) $PageUrl .= "t=" . $this->TableVar . "&"; // Add page token
		return $PageUrl;
	}

	// Message
	function getMessage() {
		return @$_SESSION[EW_SESSION_MESSAGE];
	}

	function setMessage($v) {
		ew_AddMessage($_SESSION[EW_SESSION_MESSAGE], $v);
	}

	function getFailureMessage() {
		return @$_SESSION[EW_SESSION_FAILURE_MESSAGE];
	}

	function setFailureMessage($v) {
		ew_AddMessage($_SESSION[EW_SESSION_FAILURE_MESSAGE], $v);
	}

	function getSuccessMessage() {
		return @$_SESSION[EW_SESSION_SUCCESS_MESSAGE];
	}

	function setSuccessMessage($v) {
		ew_AddMessage($_SESSION[EW_SESSION_SUCCESS_MESSAGE], $v);
	}

	function getWarningMessage() {
		return @$_SESSION[EW_SESSION_WARNING_MESSAGE];
	}

	function setWarningMessage($v) {
		ew_AddMessage($_SESSION[EW_SESSION_WARNING_MESSAGE], $v);
	}

	// Show message
	function ShowMessage() {
		$hidden = FALSE;
		$html = "";

		// Message
		$sMessage = $this->getMessage();
		$this->Message_Showing($sMessage, "");
		if ($sMessage <> "") { // Message in Session, display
			if (!$hidden)
				$sMessage = "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" . $sMessage;
			$html .= "<div class=\"alert alert-success ewSuccess\">" . $sMessage . "</div>";
			$_SESSION[EW_SESSION_MESSAGE] = ""; // Clear message in Session
		}

		// Warning message
		$sWarningMessage = $this->getWarningMessage();
		$this->Message_Showing($sWarningMessage, "warning");
		if ($sWarningMessage <> "") { // Message in Session, display
			if (!$hidden)
				$sWarningMessage = "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" . $sWarningMessage;
			$html .= "<div class=\"alert alert-warning ewWarning\">" . $sWarningMessage . "</div>";
			$_SESSION[EW_SESSION_WARNING_MESSAGE] = ""; // Clear message in Session
		}

		// Success message
		$sSuccessMessage = $this->getSuccessMessage();
		$this->Message_Showing($sSuccessMessage, "success");
		if ($sSuccessMessage <> "") { // Message in Session, display
			if (!$hidden)
				$sSuccessMessage = "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" . $sSuccessMessage;
			$html .= "<div class=\"alert alert-success ewSuccess\">" . $sSuccessMessage . "</div>";
			$_SESSION[EW_SESSION_SUCCESS_MESSAGE] = ""; // Clear message in Session
		}

		// Failure message
		$sErrorMessage = $this->getFailureMessage();
		$this->Message_Showing($sErrorMessage, "failure");
		if ($sErrorMessage <> "") { // Message in Session, display
			if (!$hidden)
				$sErrorMessage = "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" . $sErrorMessage;
			$html .= "<div class=\"alert alert-error ewError\">" . $sErrorMessage . "</div>";
			$_SESSION[EW_SESSION_FAILURE_MESSAGE] = ""; // Clear message in Session
		}
		echo "<table class=\"ewStdTable\"><tr><td><div class=\"ewMessageDialog\"" . (($hidden) ? " style=\"display: none;\"" : "") . ">" . $html . "</div></td></tr></table>";
	}
	var $PageHeader;
	var $PageFooter;

	// Show Page Header
	function ShowPageHeader() {
		$sHeader = $this->PageHeader;
		$this->Page_DataRendering($sHeader);
		if ($sHeader <> "") { // Header exists, display
			echo "<p>" . $sHeader . "</p>";
		}
	}

	// Show Page Footer
	function ShowPageFooter() {
		$sFooter = $this->PageFooter;
		$this->Page_DataRendered($sFooter);
		if ($sFooter <> "") { // Footer exists, display
			echo "<p>" . $sFooter . "</p>";
		}
	}

	// Validate page request
	function IsPageRequest() {
		global $objForm;
		if ($this->UseTokenInUrl) {
			if ($objForm)
				return ($this->TableVar == $objForm->GetValue("t"));
			if (@$_GET["t"] <> "")
				return ($this->TableVar == $_GET["t"]);
		} else {
			return TRUE;
		}
	}

	//
	// Page class constructor
	//
	function __construct() {
		global $conn, $Language, $UserAgent;

		// User agent
		$UserAgent = ew_UserAgent();
		$GLOBALS["Page"] = &$this;

		// Language object
		if (!isset($Language)) $Language = new cLanguage();

		// Parent constuctor
		parent::__construct();

		// Table object (asset)
		if (!isset($GLOBALS["asset"])) {
			$GLOBALS["asset"] = &$this;
			$GLOBALS["Table"] = &$GLOBALS["asset"];
		}

		// Page ID
		if (!defined("EW_PAGE_ID"))
			define("EW_PAGE_ID", 'delete', TRUE);

		// Table name (for backward compatibility)
		if (!defined("EW_TABLE_NAME"))
			define("EW_TABLE_NAME", 'asset', TRUE);

		// Start timer
		if (!isset($GLOBALS["gTimer"])) $GLOBALS["gTimer"] = new cTimer();

		// Open connection
		if (!isset($conn)) $conn = ew_Connect();
	}

	// 
	//  Page_Init
	//
	function Page_Init() {
		global $gsExport, $gsExportFile, $UserProfile, $Language, $Security, $objForm;
		$this->CurrentAction = (@$_GET["a"] <> "") ? $_GET["a"] : @$_POST["a_list"]; // Set up curent action
		global $gbOldSkipHeaderFooter, $gbSkipHeaderFooter;
		$gbOldSkipHeaderFooter = $gbSkipHeaderFooter;
		$gbSkipHeaderFooter = TRUE;

		// Global Page Loading event (in userfn*.php)
		Page_Loading();

		// Page Load event
		$this->Page_Load();
	}

	//
	// Page_Terminate
	//
	function Page_Terminate($url = "") {
		global $conn;
		global $gbOldSkipHeaderFooter, $gbSkipHeaderFooter;
		$gbSkipHeaderFooter = $gbOldSkipHeaderFooter;

		// Page Unload event
		$this->Page_Unload();

		// Global Page Unloaded event (in userfn*.php)
		Page_Unloaded();
		$this->Page_Redirecting($url);

		 // Close connection
		$conn->Close();

		// Go to URL if specified
		if ($url <> "") {
			if (!EW_DEBUG_ENABLED && ob_get_length())
				ob_end_clean();
			header("Location: " . $url);
		}
	}
	var $TotalRecs = 0;
	var $RecCnt;
	var $RecKeys = array();
	var $Recordset;
	var $StartRowCnt = 1;
	var $RowCnt = 0;

	//
	// Page main
	//
	function Page_Main() {
		global $Language;

		// Set up Breadcrumb
		$this->SetupBreadcrumb();

		// Load key parameters
		$this->RecKeys = $this->GetRecordKeys(); // Load record keys
		$sFilter = $this->GetKeyFilter();
		if ($sFilter == "")
			$this->Page_Terminate("assetlist.php"); // Prevent SQL injection, return to list

		// Set up filter (SQL WHHERE clause) and get return SQL
		// SQL constructor in asset class, assetinfo.php

		$this->CurrentFilter = $sFilter;

		// Get action
		if (@$_POST["a_delete"] <> "") {
			$this->CurrentAction = $_POST["a_delete"];
		} else {
			$this->CurrentAction = "I"; // Display record
		}
		switch ($this->CurrentAction) {
			case "D": // Delete
				$this->SendEmail = TRUE; // Send email on delete success
				if ($this->DeleteRows()) { // Delete rows
					if ($this->getSuccessMessage() == "")
						$this->setSuccessMessage($Language->Phrase("DeleteSuccess")); // Set up success message
					$this->Page_Terminate($this->getReturnUrl()); // Return to caller
				}
		}
	}

// No functions
	// Load recordset
	function LoadRecordset($offset = -1, $rowcnt = -1) {
		global $conn;

		// Call Recordset Selecting event
		$this->Recordset_Selecting($this->CurrentFilter);

		// Load List page SQL
		$sSql = $this->SelectSQL();
		if ($offset > -1 && $rowcnt > -1)
			$sSql .= " LIMIT $rowcnt OFFSET $offset";

		// Load recordset
		$rs = ew_LoadRecordset($sSql);

		// Call Recordset Selected event
		$this->Recordset_Selected($rs);
		return $rs;
	}

	// Load row based on key values
	function LoadRow() {
		global $conn, $Security, $Language;
		$sFilter = $this->KeyFilter();

		// Call Row Selecting event
		$this->Row_Selecting($sFilter);

		// Load SQL based on filter
		$this->CurrentFilter = $sFilter;
		$sSql = $this->SQL();
		$res = FALSE;
		$rs = ew_LoadRecordset($sSql);
		if ($rs && !$rs->EOF) {
			$res = TRUE;
			$this->LoadRowValues($rs); // Load row values
			$rs->Close();
		}
		return $res;
	}

	// Load row values from recordset
	function LoadRowValues(&$rs) {
		global $conn;
		if (!$rs || $rs->EOF) return;

		// Call Row Selected event
		$row = &$rs->fields;
		$this->Row_Selected($row);
		$this->id->setDbValue($rs->fields('id'));
		$this->id_asset_type->setDbValue($rs->fields('id_asset_type'));
		$this->name->setDbValue($rs->fields('name'));
		$this->short_description->setDbValue($rs->fields('short_description'));
		$this->aspect_ratio_1->setDbValue($rs->fields('aspect_ratio_1'));
		$this->aspect_ratio_2->setDbValue($rs->fields('aspect_ratio_2'));
		$this->id_extention->setDbValue($rs->fields('id_extention'));
		$this->size->setDbValue($rs->fields('size'));
		$this->date_create->setDbValue($rs->fields('date_create'));
		$this->date_update->setDbValue($rs->fields('date_update'));
		$this->enabled->setDbValue($rs->fields('enabled'));
		$this->file->Upload->DbValue = $rs->fields('file');
	}

	// Load DbValue from recordset
	function LoadDbValues(&$rs) {
		if (!$rs || !is_array($rs) && $rs->EOF) return;
		$row = is_array($rs) ? $rs : $rs->fields;
		$this->id->DbValue = $row['id'];
		$this->id_asset_type->DbValue = $row['id_asset_type'];
		$this->name->DbValue = $row['name'];
		$this->short_description->DbValue = $row['short_description'];
		$this->aspect_ratio_1->DbValue = $row['aspect_ratio_1'];
		$this->aspect_ratio_2->DbValue = $row['aspect_ratio_2'];
		$this->id_extention->DbValue = $row['id_extention'];
		$this->size->DbValue = $row['size'];
		$this->date_create->DbValue = $row['date_create'];
		$this->date_update->DbValue = $row['date_update'];
		$this->enabled->DbValue = $row['enabled'];
		$this->file->Upload->DbValue = $row['file'];
	}

	// Render row values based on field settings
	function RenderRow() {
		global $conn, $Security, $Language;
		global $gsLanguage;

		// Initialize URLs
		// Convert decimal values if posted back

		if ($this->aspect_ratio_1->FormValue == $this->aspect_ratio_1->CurrentValue && is_numeric(ew_StrToFloat($this->aspect_ratio_1->CurrentValue)))
			$this->aspect_ratio_1->CurrentValue = ew_StrToFloat($this->aspect_ratio_1->CurrentValue);

		// Convert decimal values if posted back
		if ($this->aspect_ratio_2->FormValue == $this->aspect_ratio_2->CurrentValue && is_numeric(ew_StrToFloat($this->aspect_ratio_2->CurrentValue)))
			$this->aspect_ratio_2->CurrentValue = ew_StrToFloat($this->aspect_ratio_2->CurrentValue);

		// Convert decimal values if posted back
		if ($this->size->FormValue == $this->size->CurrentValue && is_numeric(ew_StrToFloat($this->size->CurrentValue)))
			$this->size->CurrentValue = ew_StrToFloat($this->size->CurrentValue);

		// Call Row_Rendering event
		$this->Row_Rendering();

		// Common render codes for all row types
		// id
		// id_asset_type
		// name
		// short_description
		// aspect_ratio_1
		// aspect_ratio_2
		// id_extention
		// size
		// date_create
		// date_update
		// enabled
		// file

		if ($this->RowType == EW_ROWTYPE_VIEW) { // View row

			// id
			$this->id->ViewValue = $this->id->CurrentValue;
			$this->id->ViewCustomAttributes = "";

			// id_asset_type
			if (strval($this->id_asset_type->CurrentValue) <> "") {
				$sFilterWrk = "`id`" . ew_SearchString("=", $this->id_asset_type->CurrentValue, EW_DATATYPE_STRING);
			$sSqlWrk = "SELECT `id`, `name` AS `DispFld`, '' AS `Disp2Fld`, '' AS `Disp3Fld`, '' AS `Disp4Fld` FROM `asset_type`";
			$sWhereWrk = "";
			if ($sFilterWrk <> "") {
				ew_AddFilter($sWhereWrk, $sFilterWrk);
			}

			// Call Lookup selecting
			$this->Lookup_Selecting($this->id_asset_type, $sWhereWrk);
			if ($sWhereWrk <> "") $sSqlWrk .= " WHERE " . $sWhereWrk;
				$rswrk = $conn->Execute($sSqlWrk);
				if ($rswrk && !$rswrk->EOF) { // Lookup values found
					$this->id_asset_type->ViewValue = $rswrk->fields('DispFld');
					$rswrk->Close();
				} else {
					$this->id_asset_type->ViewValue = $this->id_asset_type->CurrentValue;
				}
			} else {
				$this->id_asset_type->ViewValue = NULL;
			}
			$this->id_asset_type->ViewCustomAttributes = "";

			// name
			$this->name->ViewValue = $this->name->CurrentValue;
			$this->name->CssStyle = "font-weight: bold;";
			$this->name->ViewCustomAttributes = "";

			// short_description
			$this->short_description->ViewValue = $this->short_description->CurrentValue;
			$this->short_description->ViewCustomAttributes = "";

			// aspect_ratio_1
			$this->aspect_ratio_1->ViewValue = $this->aspect_ratio_1->CurrentValue;
			$this->aspect_ratio_1->ViewCustomAttributes = "";

			// aspect_ratio_2
			$this->aspect_ratio_2->ViewValue = $this->aspect_ratio_2->CurrentValue;
			$this->aspect_ratio_2->ViewCustomAttributes = "";

			// id_extention
			if (strval($this->id_extention->CurrentValue) <> "") {
				$sFilterWrk = "`id`" . ew_SearchString("=", $this->id_extention->CurrentValue, EW_DATATYPE_STRING);
			$sSqlWrk = "SELECT `id`, `name` AS `DispFld`, '' AS `Disp2Fld`, '' AS `Disp3Fld`, '' AS `Disp4Fld` FROM `extention`";
			$sWhereWrk = "";
			if ($sFilterWrk <> "") {
				ew_AddFilter($sWhereWrk, $sFilterWrk);
			}

			// Call Lookup selecting
			$this->Lookup_Selecting($this->id_extention, $sWhereWrk);
			if ($sWhereWrk <> "") $sSqlWrk .= " WHERE " . $sWhereWrk;
				$rswrk = $conn->Execute($sSqlWrk);
				if ($rswrk && !$rswrk->EOF) { // Lookup values found
					$this->id_extention->ViewValue = $rswrk->fields('DispFld');
					$rswrk->Close();
				} else {
					$this->id_extention->ViewValue = $this->id_extention->CurrentValue;
				}
			} else {
				$this->id_extention->ViewValue = NULL;
			}
			$this->id_extention->ViewCustomAttributes = "";

			// size
			$this->size->ViewValue = $this->size->CurrentValue;
			$this->size->ViewCustomAttributes = "";

			// date_create
			$this->date_create->ViewValue = $this->date_create->CurrentValue;
			$this->date_create->ViewValue = ew_FormatDateTime($this->date_create->ViewValue, 9);
			$this->date_create->ViewCustomAttributes = "";

			// date_update
			$this->date_update->ViewValue = $this->date_update->CurrentValue;
			$this->date_update->ViewValue = ew_FormatDateTime($this->date_update->ViewValue, 9);
			$this->date_update->ViewCustomAttributes = "";

			// enabled
			if (strval($this->enabled->CurrentValue) <> "") {
				switch ($this->enabled->CurrentValue) {
					case $this->enabled->FldTagValue(1):
						$this->enabled->ViewValue = $this->enabled->FldTagCaption(1) <> "" ? $this->enabled->FldTagCaption(1) : $this->enabled->CurrentValue;
						break;
					case $this->enabled->FldTagValue(2):
						$this->enabled->ViewValue = $this->enabled->FldTagCaption(2) <> "" ? $this->enabled->FldTagCaption(2) : $this->enabled->CurrentValue;
						break;
					default:
						$this->enabled->ViewValue = $this->enabled->CurrentValue;
				}
			} else {
				$this->enabled->ViewValue = NULL;
			}
			$this->enabled->ViewCustomAttributes = "";

			// file
			if (!ew_Empty($this->file->Upload->DbValue)) {
				$this->file->ViewValue = $this->file->Upload->DbValue;
			} else {
				$this->file->ViewValue = "";
			}
			$this->file->ViewCustomAttributes = "";

			// id_asset_type
			$this->id_asset_type->LinkCustomAttributes = "";
			$this->id_asset_type->HrefValue = "";
			$this->id_asset_type->TooltipValue = "";

			// name
			$this->name->LinkCustomAttributes = "";
			$this->name->HrefValue = "";
			$this->name->TooltipValue = "";

			// aspect_ratio_1
			$this->aspect_ratio_1->LinkCustomAttributes = "";
			$this->aspect_ratio_1->HrefValue = "";
			$this->aspect_ratio_1->TooltipValue = "";

			// aspect_ratio_2
			$this->aspect_ratio_2->LinkCustomAttributes = "";
			$this->aspect_ratio_2->HrefValue = "";
			$this->aspect_ratio_2->TooltipValue = "";

			// id_extention
			$this->id_extention->LinkCustomAttributes = "";
			$this->id_extention->HrefValue = "";
			$this->id_extention->TooltipValue = "";

			// size
			$this->size->LinkCustomAttributes = "";
			$this->size->HrefValue = "";
			$this->size->TooltipValue = "";

			// enabled
			$this->enabled->LinkCustomAttributes = "";
			$this->enabled->HrefValue = "";
			$this->enabled->TooltipValue = "";
		}

		// Call Row Rendered event
		if ($this->RowType <> EW_ROWTYPE_AGGREGATEINIT)
			$this->Row_Rendered();
	}

	//
	// Delete records based on current filter
	//
	function DeleteRows() {
		global $conn, $Language, $Security;
		$DeleteRows = TRUE;
		$sSql = $this->SQL();
		$conn->raiseErrorFn = 'ew_ErrorFn';
		$rs = $conn->Execute($sSql);
		$conn->raiseErrorFn = '';
		if ($rs === FALSE) {
			return FALSE;
		} elseif ($rs->EOF) {
			$this->setFailureMessage($Language->Phrase("NoRecord")); // No record found
			$rs->Close();
			return FALSE;

		//} else {
		//	$this->LoadRowValues($rs); // Load row values

		}
		$conn->BeginTrans();

		// Clone old rows
		$rsold = ($rs) ? $rs->GetRows() : array();
		if ($rs)
			$rs->Close();

		// Call row deleting event
		if ($DeleteRows) {
			foreach ($rsold as $row) {
				$DeleteRows = $this->Row_Deleting($row);
				if (!$DeleteRows) break;
			}
		}
		if ($DeleteRows) {
			$sKey = "";
			foreach ($rsold as $row) {
				$sThisKey = "";
				if ($sThisKey <> "") $sThisKey .= $GLOBALS["EW_COMPOSITE_KEY_SEPARATOR"];
				$sThisKey .= $row['id'];
				$conn->raiseErrorFn = 'ew_ErrorFn';
				$DeleteRows = $this->Delete($row); // Delete
				$conn->raiseErrorFn = '';
				if ($DeleteRows === FALSE)
					break;
				if ($sKey <> "") $sKey .= ", ";
				$sKey .= $sThisKey;
			}
		} else {

			// Set up error message
			if ($this->getSuccessMessage() <> "" || $this->getFailureMessage() <> "") {

				// Use the message, do nothing
			} elseif ($this->CancelMessage <> "") {
				$this->setFailureMessage($this->CancelMessage);
				$this->CancelMessage = "";
			} else {
				$this->setFailureMessage($Language->Phrase("DeleteCancelled"));
			}
		}
		if ($DeleteRows) {
			$conn->CommitTrans(); // Commit the changes
		} else {
			$conn->RollbackTrans(); // Rollback changes
		}

		// Call Row Deleted event
		if ($DeleteRows) {
			foreach ($rsold as $row) {
				$this->Row_Deleted($row);
			}
		}
		return $DeleteRows;
	}

	// Set up Breadcrumb
	function SetupBreadcrumb() {
		global $Breadcrumb, $Language;
		$Breadcrumb = new cBreadcrumb();
		$PageCaption = $this->TableCaption();
		$Breadcrumb->Add("list", "<span id=\"ewPageCaption\">" . $PageCaption . "</span>", "assetlist.php", $this->TableVar);
		$PageCaption = $Language->Phrase("delete");
		$Breadcrumb->Add("delete", "<span id=\"ewPageCaption\">" . $PageCaption . "</span>", ew_CurrentUrl(), $this->TableVar);
	}

	// Page Load event
	function Page_Load() {

		//echo "Page Load";
	}

	// Page Unload event
	function Page_Unload() {

		//echo "Page Unload";
	}

	// Page Redirecting event
	function Page_Redirecting(&$url) {

		// Example:
		//$url = "your URL";

	}

	// Message Showing event
	// $type = ''|'success'|'failure'|'warning'
	function Message_Showing(&$msg, $type) {
		if ($type == 'success') {

			//$msg = "your success message";
		} elseif ($type == 'failure') {

			//$msg = "your failure message";
		} elseif ($type == 'warning') {

			//$msg = "your warning message";
		} else {

			//$msg = "your message";
		}
	}

	// Page Render event
	function Page_Render() {

		//echo "Page Render";
	}

	// Page Data Rendering event
	function Page_DataRendering(&$header) {

		// Example:
		//$header = "your header";

	}

	// Page Data Rendered event
	function Page_DataRendered(&$footer) {

		// Example:
		//$footer = "your footer";

	}
}
?>
<?php ew_Header(FALSE) ?>
<?php

// Create page object
if (!isset($asset_delete)) $asset_delete = new casset_delete();

// Page init
$asset_delete->Page_Init();

// Page main
$asset_delete->Page_Main();

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$asset_delete->Page_Render();
?>
<?php include_once "header.php" ?>
<script type="text/javascript">

// Page object
var asset_delete = new ew_Page("asset_delete");
asset_delete.PageID = "delete"; // Page ID
var EW_PAGE_ID = asset_delete.PageID; // For backward compatibility

// Form object
var fassetdelete = new ew_Form("fassetdelete");

// Form_CustomValidate event
fassetdelete.Form_CustomValidate = 
 function(fobj) { // DO NOT CHANGE THIS LINE!

 	// Your custom validation code here, return false if invalid. 
 	return true;
 }

// Use JavaScript validation or not
<?php if (EW_CLIENT_VALIDATE) { ?>
fassetdelete.ValidateRequired = true;
<?php } else { ?>
fassetdelete.ValidateRequired = false; 
<?php } ?>

// Dynamic selection lists
fassetdelete.Lists["x_id_asset_type"] = {"LinkField":"x_id","Ajax":null,"AutoFill":false,"DisplayFields":["x_name","","",""],"ParentFields":[],"FilterFields":[],"Options":[]};
fassetdelete.Lists["x_id_extention"] = {"LinkField":"x_id","Ajax":null,"AutoFill":false,"DisplayFields":["x_name","","",""],"ParentFields":[],"FilterFields":[],"Options":[]};

// Form object for search
</script>
<script type="text/javascript">

// Write your client script here, no need to add script tags.
</script>
<?php

// Load records for display
if ($asset_delete->Recordset = $asset_delete->LoadRecordset())
	$asset_deleteTotalRecs = $asset_delete->Recordset->RecordCount(); // Get record count
if ($asset_deleteTotalRecs <= 0) { // No record found, exit
	if ($asset_delete->Recordset)
		$asset_delete->Recordset->Close();
	$asset_delete->Page_Terminate("assetlist.php"); // Return to list
}
?>
<?php $Breadcrumb->Render(); ?>
<?php $asset_delete->ShowPageHeader(); ?>
<?php
$asset_delete->ShowMessage();
?>
<form name="fassetdelete" id="fassetdelete" class="ewForm form-horizontal" action="<?php echo ew_CurrentPage() ?>" method="post">
<input type="hidden" name="t" value="asset">
<input type="hidden" name="a_delete" id="a_delete" value="D">
<?php foreach ($asset_delete->RecKeys as $key) { ?>
<?php $keyvalue = is_array($key) ? implode($EW_COMPOSITE_KEY_SEPARATOR, $key) : $key; ?>
<input type="hidden" name="key_m[]" value="<?php echo ew_HtmlEncode($keyvalue) ?>">
<?php } ?>
<table cellspacing="0" class="ewGrid"><tr><td class="ewGridContent">
<div class="ewGridMiddlePanel">
<table id="tbl_assetdelete" class="ewTable ewTableSeparate">
<?php echo $asset->TableCustomInnerHtml ?>
	<thead>
	<tr class="ewTableHeader">
<?php if ($asset->id_asset_type->Visible) { // id_asset_type ?>
		<td><span id="elh_asset_id_asset_type" class="asset_id_asset_type"><?php echo $asset->id_asset_type->FldCaption() ?></span></td>
<?php } ?>
<?php if ($asset->name->Visible) { // name ?>
		<td><span id="elh_asset_name" class="asset_name"><?php echo $asset->name->FldCaption() ?></span></td>
<?php } ?>
<?php if ($asset->aspect_ratio_1->Visible) { // aspect_ratio_1 ?>
		<td><span id="elh_asset_aspect_ratio_1" class="asset_aspect_ratio_1"><?php echo $asset->aspect_ratio_1->FldCaption() ?></span></td>
<?php } ?>
<?php if ($asset->aspect_ratio_2->Visible) { // aspect_ratio_2 ?>
		<td><span id="elh_asset_aspect_ratio_2" class="asset_aspect_ratio_2"><?php echo $asset->aspect_ratio_2->FldCaption() ?></span></td>
<?php } ?>
<?php if ($asset->id_extention->Visible) { // id_extention ?>
		<td><span id="elh_asset_id_extention" class="asset_id_extention"><?php echo $asset->id_extention->FldCaption() ?></span></td>
<?php } ?>
<?php if ($asset->size->Visible) { // size ?>
		<td><span id="elh_asset_size" class="asset_size"><?php echo $asset->size->FldCaption() ?></span></td>
<?php } ?>
<?php if ($asset->enabled->Visible) { // enabled ?>
		<td><span id="elh_asset_enabled" class="asset_enabled"><?php echo $asset->enabled->FldCaption() ?></span></td>
<?php } ?>
	</tr>
	</thead>
	<tbody>
<?php
$asset_delete->RecCnt = 0;
$i = 0;
while (!$asset_delete->Recordset->EOF) {
	$asset_delete->RecCnt++;
	$asset_delete->RowCnt++;

	// Set row properties
	$asset->ResetAttrs();
	$asset->RowType = EW_ROWTYPE_VIEW; // View

	// Get the field contents
	$asset_delete->LoadRowValues($asset_delete->Recordset);

	// Render row
	$asset_delete->RenderRow();
?>
	<tr<?php echo $asset->RowAttributes() ?>>
<?php if ($asset->id_asset_type->Visible) { // id_asset_type ?>
		<td<?php echo $asset->id_asset_type->CellAttributes() ?>>
<span id="el<?php echo $asset_delete->RowCnt ?>_asset_id_asset_type" class="control-group asset_id_asset_type">
<span<?php echo $asset->id_asset_type->ViewAttributes() ?>>
<?php echo $asset->id_asset_type->ListViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($asset->name->Visible) { // name ?>
		<td<?php echo $asset->name->CellAttributes() ?>>
<span id="el<?php echo $asset_delete->RowCnt ?>_asset_name" class="control-group asset_name">
<span<?php echo $asset->name->ViewAttributes() ?>>
<?php echo $asset->name->ListViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($asset->aspect_ratio_1->Visible) { // aspect_ratio_1 ?>
		<td<?php echo $asset->aspect_ratio_1->CellAttributes() ?>>
<span id="el<?php echo $asset_delete->RowCnt ?>_asset_aspect_ratio_1" class="control-group asset_aspect_ratio_1">
<span<?php echo $asset->aspect_ratio_1->ViewAttributes() ?>>
<?php echo $asset->aspect_ratio_1->ListViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($asset->aspect_ratio_2->Visible) { // aspect_ratio_2 ?>
		<td<?php echo $asset->aspect_ratio_2->CellAttributes() ?>>
<span id="el<?php echo $asset_delete->RowCnt ?>_asset_aspect_ratio_2" class="control-group asset_aspect_ratio_2">
<span<?php echo $asset->aspect_ratio_2->ViewAttributes() ?>>
<?php echo $asset->aspect_ratio_2->ListViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($asset->id_extention->Visible) { // id_extention ?>
		<td<?php echo $asset->id_extention->CellAttributes() ?>>
<span id="el<?php echo $asset_delete->RowCnt ?>_asset_id_extention" class="control-group asset_id_extention">
<span<?php echo $asset->id_extention->ViewAttributes() ?>>
<?php echo $asset->id_extention->ListViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($asset->size->Visible) { // size ?>
		<td<?php echo $asset->size->CellAttributes() ?>>
<span id="el<?php echo $asset_delete->RowCnt ?>_asset_size" class="control-group asset_size">
<span<?php echo $asset->size->ViewAttributes() ?>>
<?php echo $asset->size->ListViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($asset->enabled->Visible) { // enabled ?>
		<td<?php echo $asset->enabled->CellAttributes() ?>>
<span id="el<?php echo $asset_delete->RowCnt ?>_asset_enabled" class="control-group asset_enabled">
<span<?php echo $asset->enabled->ViewAttributes() ?>>
<?php echo $asset->enabled->ListViewValue() ?></span>
</span>
</td>
<?php } ?>
	</tr>
<?php
	$asset_delete->Recordset->MoveNext();
}
$asset_delete->Recordset->Close();
?>
</tbody>
</table>
</div>
</td></tr></table>
<div class="btn-group ewButtonGroup">
<button class="btn btn-primary ewButton" name="btnAction" id="btnAction" type="submit"><?php echo $Language->Phrase("DeleteBtn") ?></button>
</div>
</form>
<script type="text/javascript">
fassetdelete.Init();
</script>
<?php
$asset_delete->ShowPageFooter();
if (EW_DEBUG_ENABLED)
	echo ew_DebugMsg();
?>
<script type="text/javascript">

// Write your table-specific startup script here
// document.write("page loaded");

</script>
<?php include_once "footer.php" ?>
<?php
$asset_delete->Page_Terminate();
?>
