<?php
if (session_id() == "") session_start(); // Initialize Session data
ob_start(); // Turn on output buffering
?>
<?php include_once "ewcfg10.php" ?>
<?php include_once "ewmysql10.php" ?>
<?php include_once "phpfn10.php" ?>
<?php include_once "assetinfo.php" ?>
<?php include_once "userfn10.php" ?>
<?php

//
// Page class
//

$asset_add = NULL; // Initialize page object first

class casset_add extends casset {

	// Page ID
	var $PageID = 'add';

	// Project ID
	var $ProjectID = "{3F4DCFAD-76CE-4EF9-8198-C7C0BA2B5B2C}";

	// Table name
	var $TableName = 'asset';

	// Page object name
	var $PageObjName = 'asset_add';

	// Page name
	function PageName() {
		return ew_CurrentPage();
	}

	// Page URL
	function PageUrl() {
		$PageUrl = ew_CurrentPage() . "?";
		if ($this->UseTokenInUrl) $PageUrl .= "t=" . $this->TableVar . "&"; // Add page token
		return $PageUrl;
	}

	// Message
	function getMessage() {
		return @$_SESSION[EW_SESSION_MESSAGE];
	}

	function setMessage($v) {
		ew_AddMessage($_SESSION[EW_SESSION_MESSAGE], $v);
	}

	function getFailureMessage() {
		return @$_SESSION[EW_SESSION_FAILURE_MESSAGE];
	}

	function setFailureMessage($v) {
		ew_AddMessage($_SESSION[EW_SESSION_FAILURE_MESSAGE], $v);
	}

	function getSuccessMessage() {
		return @$_SESSION[EW_SESSION_SUCCESS_MESSAGE];
	}

	function setSuccessMessage($v) {
		ew_AddMessage($_SESSION[EW_SESSION_SUCCESS_MESSAGE], $v);
	}

	function getWarningMessage() {
		return @$_SESSION[EW_SESSION_WARNING_MESSAGE];
	}

	function setWarningMessage($v) {
		ew_AddMessage($_SESSION[EW_SESSION_WARNING_MESSAGE], $v);
	}

	// Show message
	function ShowMessage() {
		$hidden = FALSE;
		$html = "";

		// Message
		$sMessage = $this->getMessage();
		$this->Message_Showing($sMessage, "");
		if ($sMessage <> "") { // Message in Session, display
			if (!$hidden)
				$sMessage = "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" . $sMessage;
			$html .= "<div class=\"alert alert-success ewSuccess\">" . $sMessage . "</div>";
			$_SESSION[EW_SESSION_MESSAGE] = ""; // Clear message in Session
		}

		// Warning message
		$sWarningMessage = $this->getWarningMessage();
		$this->Message_Showing($sWarningMessage, "warning");
		if ($sWarningMessage <> "") { // Message in Session, display
			if (!$hidden)
				$sWarningMessage = "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" . $sWarningMessage;
			$html .= "<div class=\"alert alert-warning ewWarning\">" . $sWarningMessage . "</div>";
			$_SESSION[EW_SESSION_WARNING_MESSAGE] = ""; // Clear message in Session
		}

		// Success message
		$sSuccessMessage = $this->getSuccessMessage();
		$this->Message_Showing($sSuccessMessage, "success");
		if ($sSuccessMessage <> "") { // Message in Session, display
			if (!$hidden)
				$sSuccessMessage = "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" . $sSuccessMessage;
			$html .= "<div class=\"alert alert-success ewSuccess\">" . $sSuccessMessage . "</div>";
			$_SESSION[EW_SESSION_SUCCESS_MESSAGE] = ""; // Clear message in Session
		}

		// Failure message
		$sErrorMessage = $this->getFailureMessage();
		$this->Message_Showing($sErrorMessage, "failure");
		if ($sErrorMessage <> "") { // Message in Session, display
			if (!$hidden)
				$sErrorMessage = "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" . $sErrorMessage;
			$html .= "<div class=\"alert alert-error ewError\">" . $sErrorMessage . "</div>";
			$_SESSION[EW_SESSION_FAILURE_MESSAGE] = ""; // Clear message in Session
		}
		echo "<table class=\"ewStdTable\"><tr><td><div class=\"ewMessageDialog\"" . (($hidden) ? " style=\"display: none;\"" : "") . ">" . $html . "</div></td></tr></table>";
	}
	var $PageHeader;
	var $PageFooter;

	// Show Page Header
	function ShowPageHeader() {
		$sHeader = $this->PageHeader;
		$this->Page_DataRendering($sHeader);
		if ($sHeader <> "") { // Header exists, display
			echo "<p>" . $sHeader . "</p>";
		}
	}

	// Show Page Footer
	function ShowPageFooter() {
		$sFooter = $this->PageFooter;
		$this->Page_DataRendered($sFooter);
		if ($sFooter <> "") { // Footer exists, display
			echo "<p>" . $sFooter . "</p>";
		}
	}

	// Validate page request
	function IsPageRequest() {
		global $objForm;
		if ($this->UseTokenInUrl) {
			if ($objForm)
				return ($this->TableVar == $objForm->GetValue("t"));
			if (@$_GET["t"] <> "")
				return ($this->TableVar == $_GET["t"]);
		} else {
			return TRUE;
		}
	}

	//
	// Page class constructor
	//
	function __construct() {
		global $conn, $Language, $UserAgent;

		// User agent
		$UserAgent = ew_UserAgent();
		$GLOBALS["Page"] = &$this;

		// Language object
		if (!isset($Language)) $Language = new cLanguage();

		// Parent constuctor
		parent::__construct();

		// Table object (asset)
		if (!isset($GLOBALS["asset"])) {
			$GLOBALS["asset"] = &$this;
			$GLOBALS["Table"] = &$GLOBALS["asset"];
		}

		// Page ID
		if (!defined("EW_PAGE_ID"))
			define("EW_PAGE_ID", 'add', TRUE);

		// Table name (for backward compatibility)
		if (!defined("EW_TABLE_NAME"))
			define("EW_TABLE_NAME", 'asset', TRUE);

		// Start timer
		if (!isset($GLOBALS["gTimer"])) $GLOBALS["gTimer"] = new cTimer();

		// Open connection
		if (!isset($conn)) $conn = ew_Connect();
	}

	// 
	//  Page_Init
	//
	function Page_Init() {
		global $gsExport, $gsExportFile, $UserProfile, $Language, $Security, $objForm;

		// Create form object
		$objForm = new cFormObj();
		$this->CurrentAction = (@$_GET["a"] <> "") ? $_GET["a"] : @$_POST["a_list"]; // Set up curent action
		global $gbOldSkipHeaderFooter, $gbSkipHeaderFooter;
		$gbOldSkipHeaderFooter = $gbSkipHeaderFooter;
		$gbSkipHeaderFooter = TRUE;

		// Global Page Loading event (in userfn*.php)
		Page_Loading();

		// Page Load event
		$this->Page_Load();
	}

	//
	// Page_Terminate
	//
	function Page_Terminate($url = "") {
		global $conn;
		global $gbOldSkipHeaderFooter, $gbSkipHeaderFooter;
		$gbSkipHeaderFooter = $gbOldSkipHeaderFooter;

		// Page Unload event
		$this->Page_Unload();

		// Global Page Unloaded event (in userfn*.php)
		Page_Unloaded();
		$this->Page_Redirecting($url);

		 // Close connection
		$conn->Close();

		// Go to URL if specified
		if ($url <> "") {
			if (!EW_DEBUG_ENABLED && ob_get_length())
				ob_end_clean();
			header("Location: " . $url);
		}
	}
	var $DbMasterFilter = "";
	var $DbDetailFilter = "";
	var $Priv = 0;
	var $OldRecordset;
	var $CopyRecord;

	// 
	// Page main
	//
	function Page_Main() {
		global $objForm, $Language, $gsFormError;

		// Process form if post back
		if (@$_POST["a_add"] <> "") {
			$this->CurrentAction = $_POST["a_add"]; // Get form action
			$this->CopyRecord = $this->LoadOldRecord(); // Load old recordset
			$this->LoadFormValues(); // Load form values
		} else { // Not post back

			// Load key values from QueryString
			$this->CopyRecord = TRUE;
			if (@$_GET["id"] != "") {
				$this->id->setQueryStringValue($_GET["id"]);
				$this->setKey("id", $this->id->CurrentValue); // Set up key
			} else {
				$this->setKey("id", ""); // Clear key
				$this->CopyRecord = FALSE;
			}
			if ($this->CopyRecord) {
				$this->CurrentAction = "C"; // Copy record
			} else {
				$this->CurrentAction = "I"; // Display blank record
				$this->LoadDefaultValues(); // Load default values
			}
		}

		// Set up Breadcrumb
		$this->SetupBreadcrumb();

		// Validate form if post back
		if (@$_POST["a_add"] <> "") {
			if (!$this->ValidateForm()) {
				$this->CurrentAction = "I"; // Form error, reset action
				$this->EventCancelled = TRUE; // Event cancelled
				$this->RestoreFormValues(); // Restore form values
				$this->setFailureMessage($gsFormError);
			}
		}

		// Perform action based on action code
		switch ($this->CurrentAction) {
			case "I": // Blank record, no action required
				break;
			case "C": // Copy an existing record
				if (!$this->LoadRow()) { // Load record based on key
					if ($this->getFailureMessage() == "") $this->setFailureMessage($Language->Phrase("NoRecord")); // No record found
					$this->Page_Terminate("assetlist.php"); // No matching record, return to list
				}
				break;
			case "A": // Add new record
				$this->SendEmail = TRUE; // Send email on add success
				if ($this->AddRow($this->OldRecordset)) { // Add successful
					if ($this->getSuccessMessage() == "")
						$this->setSuccessMessage($Language->Phrase("AddSuccess")); // Set up success message
					$sReturnUrl = $this->getReturnUrl();
					if (ew_GetPageName($sReturnUrl) == "assetview.php")
						$sReturnUrl = $this->GetViewUrl(); // View paging, return to view page with keyurl directly
					$this->Page_Terminate($sReturnUrl); // Clean up and return
				} else {
					$this->EventCancelled = TRUE; // Event cancelled
					$this->RestoreFormValues(); // Add failed, restore form values
				}
		}

		// Render row based on row type
		$this->RowType = EW_ROWTYPE_ADD;  // Render add type

		// Render row
		$this->ResetAttrs();
		$this->RenderRow();
	}

	// Get upload files
	function GetUploadFiles() {
		global $objForm;

		// Get upload data
		$this->file->Upload->Index = $objForm->Index;
		if ($this->file->Upload->UploadFile()) {

			// No action required
		} else {
			echo $this->file->Upload->Message;
			$this->Page_Terminate();
			exit();
		}
		$this->file->CurrentValue = $this->file->Upload->FileName;
		$this->size->CurrentValue = $this->file->Upload->FileSize;
	}

	// Load default values
	function LoadDefaultValues() {
		$this->id->CurrentValue = md5(uniqid());
		$this->id_asset_type->CurrentValue = NULL;
		$this->id_asset_type->OldValue = $this->id_asset_type->CurrentValue;
		$this->name->CurrentValue = NULL;
		$this->name->OldValue = $this->name->CurrentValue;
		$this->short_description->CurrentValue = NULL;
		$this->short_description->OldValue = $this->short_description->CurrentValue;
		$this->aspect_ratio_1->CurrentValue = NULL;
		$this->aspect_ratio_1->OldValue = $this->aspect_ratio_1->CurrentValue;
		$this->aspect_ratio_2->CurrentValue = NULL;
		$this->aspect_ratio_2->OldValue = $this->aspect_ratio_2->CurrentValue;
		$this->id_extention->CurrentValue = NULL;
		$this->id_extention->OldValue = $this->id_extention->CurrentValue;
		$this->size->CurrentValue = NULL;
		$this->size->OldValue = $this->size->CurrentValue;
		$this->size->CurrentValue = NULL; // Clear file related field
		$this->enabled->CurrentValue = 1;
		$this->file->Upload->DbValue = NULL;
		$this->file->OldValue = $this->file->Upload->DbValue;
		$this->file->CurrentValue = NULL; // Clear file related field
	}

	// Load form values
	function LoadFormValues() {

		// Load from form
		global $objForm;
		$this->GetUploadFiles(); // Get upload files
		if (!$this->id->FldIsDetailKey) {
			$this->id->setFormValue($objForm->GetValue("x_id"));
		}
		if (!$this->id_asset_type->FldIsDetailKey) {
			$this->id_asset_type->setFormValue($objForm->GetValue("x_id_asset_type"));
		}
		if (!$this->name->FldIsDetailKey) {
			$this->name->setFormValue($objForm->GetValue("x_name"));
		}
		if (!$this->short_description->FldIsDetailKey) {
			$this->short_description->setFormValue($objForm->GetValue("x_short_description"));
		}
		if (!$this->aspect_ratio_1->FldIsDetailKey) {
			$this->aspect_ratio_1->setFormValue($objForm->GetValue("x_aspect_ratio_1"));
		}
		if (!$this->aspect_ratio_2->FldIsDetailKey) {
			$this->aspect_ratio_2->setFormValue($objForm->GetValue("x_aspect_ratio_2"));
		}
		if (!$this->id_extention->FldIsDetailKey) {
			$this->id_extention->setFormValue($objForm->GetValue("x_id_extention"));
		}
		if (!$this->size->FldIsDetailKey) {
			$this->size->setFormValue($objForm->GetValue("x_size"));
		}
		if (!$this->enabled->FldIsDetailKey) {
			$this->enabled->setFormValue($objForm->GetValue("x_enabled"));
		}
	}

	// Restore form values
	function RestoreFormValues() {
		global $objForm;
		$this->LoadOldRecord();
		$this->id->CurrentValue = $this->id->FormValue;
		$this->id_asset_type->CurrentValue = $this->id_asset_type->FormValue;
		$this->name->CurrentValue = $this->name->FormValue;
		$this->short_description->CurrentValue = $this->short_description->FormValue;
		$this->aspect_ratio_1->CurrentValue = $this->aspect_ratio_1->FormValue;
		$this->aspect_ratio_2->CurrentValue = $this->aspect_ratio_2->FormValue;
		$this->id_extention->CurrentValue = $this->id_extention->FormValue;
		$this->enabled->CurrentValue = $this->enabled->FormValue;
	}

	// Load row based on key values
	function LoadRow() {
		global $conn, $Security, $Language;
		$sFilter = $this->KeyFilter();

		// Call Row Selecting event
		$this->Row_Selecting($sFilter);

		// Load SQL based on filter
		$this->CurrentFilter = $sFilter;
		$sSql = $this->SQL();
		$res = FALSE;
		$rs = ew_LoadRecordset($sSql);
		if ($rs && !$rs->EOF) {
			$res = TRUE;
			$this->LoadRowValues($rs); // Load row values
			$rs->Close();
		}
		return $res;
	}

	// Load row values from recordset
	function LoadRowValues(&$rs) {
		global $conn;
		if (!$rs || $rs->EOF) return;

		// Call Row Selected event
		$row = &$rs->fields;
		$this->Row_Selected($row);
		$this->id->setDbValue($rs->fields('id'));
		$this->id_asset_type->setDbValue($rs->fields('id_asset_type'));
		$this->name->setDbValue($rs->fields('name'));
		$this->short_description->setDbValue($rs->fields('short_description'));
		$this->aspect_ratio_1->setDbValue($rs->fields('aspect_ratio_1'));
		$this->aspect_ratio_2->setDbValue($rs->fields('aspect_ratio_2'));
		$this->id_extention->setDbValue($rs->fields('id_extention'));
		$this->size->setDbValue($rs->fields('size'));
		$this->date_create->setDbValue($rs->fields('date_create'));
		$this->date_update->setDbValue($rs->fields('date_update'));
		$this->enabled->setDbValue($rs->fields('enabled'));
		$this->file->Upload->DbValue = $rs->fields('file');
	}

	// Load DbValue from recordset
	function LoadDbValues(&$rs) {
		if (!$rs || !is_array($rs) && $rs->EOF) return;
		$row = is_array($rs) ? $rs : $rs->fields;
		$this->id->DbValue = $row['id'];
		$this->id_asset_type->DbValue = $row['id_asset_type'];
		$this->name->DbValue = $row['name'];
		$this->short_description->DbValue = $row['short_description'];
		$this->aspect_ratio_1->DbValue = $row['aspect_ratio_1'];
		$this->aspect_ratio_2->DbValue = $row['aspect_ratio_2'];
		$this->id_extention->DbValue = $row['id_extention'];
		$this->size->DbValue = $row['size'];
		$this->date_create->DbValue = $row['date_create'];
		$this->date_update->DbValue = $row['date_update'];
		$this->enabled->DbValue = $row['enabled'];
		$this->file->Upload->DbValue = $row['file'];
	}

	// Load old record
	function LoadOldRecord() {

		// Load key values from Session
		$bValidKey = TRUE;
		if (strval($this->getKey("id")) <> "")
			$this->id->CurrentValue = $this->getKey("id"); // id
		else
			$bValidKey = FALSE;

		// Load old recordset
		if ($bValidKey) {
			$this->CurrentFilter = $this->KeyFilter();
			$sSql = $this->SQL();
			$this->OldRecordset = ew_LoadRecordset($sSql);
			$this->LoadRowValues($this->OldRecordset); // Load row values
		} else {
			$this->OldRecordset = NULL;
		}
		return $bValidKey;
	}

	// Render row values based on field settings
	function RenderRow() {
		global $conn, $Security, $Language;
		global $gsLanguage;

		// Initialize URLs
		// Convert decimal values if posted back

		if ($this->aspect_ratio_1->FormValue == $this->aspect_ratio_1->CurrentValue && is_numeric(ew_StrToFloat($this->aspect_ratio_1->CurrentValue)))
			$this->aspect_ratio_1->CurrentValue = ew_StrToFloat($this->aspect_ratio_1->CurrentValue);

		// Convert decimal values if posted back
		if ($this->aspect_ratio_2->FormValue == $this->aspect_ratio_2->CurrentValue && is_numeric(ew_StrToFloat($this->aspect_ratio_2->CurrentValue)))
			$this->aspect_ratio_2->CurrentValue = ew_StrToFloat($this->aspect_ratio_2->CurrentValue);

		// Convert decimal values if posted back
		if ($this->size->FormValue == $this->size->CurrentValue && is_numeric(ew_StrToFloat($this->size->CurrentValue)))
			$this->size->CurrentValue = ew_StrToFloat($this->size->CurrentValue);

		// Call Row_Rendering event
		$this->Row_Rendering();

		// Common render codes for all row types
		// id
		// id_asset_type
		// name
		// short_description
		// aspect_ratio_1
		// aspect_ratio_2
		// id_extention
		// size
		// date_create
		// date_update
		// enabled
		// file

		if ($this->RowType == EW_ROWTYPE_VIEW) { // View row

			// id
			$this->id->ViewValue = $this->id->CurrentValue;
			$this->id->ViewCustomAttributes = "";

			// id_asset_type
			if (strval($this->id_asset_type->CurrentValue) <> "") {
				$sFilterWrk = "`id`" . ew_SearchString("=", $this->id_asset_type->CurrentValue, EW_DATATYPE_STRING);
			$sSqlWrk = "SELECT `id`, `name` AS `DispFld`, '' AS `Disp2Fld`, '' AS `Disp3Fld`, '' AS `Disp4Fld` FROM `asset_type`";
			$sWhereWrk = "";
			if ($sFilterWrk <> "") {
				ew_AddFilter($sWhereWrk, $sFilterWrk);
			}

			// Call Lookup selecting
			$this->Lookup_Selecting($this->id_asset_type, $sWhereWrk);
			if ($sWhereWrk <> "") $sSqlWrk .= " WHERE " . $sWhereWrk;
				$rswrk = $conn->Execute($sSqlWrk);
				if ($rswrk && !$rswrk->EOF) { // Lookup values found
					$this->id_asset_type->ViewValue = $rswrk->fields('DispFld');
					$rswrk->Close();
				} else {
					$this->id_asset_type->ViewValue = $this->id_asset_type->CurrentValue;
				}
			} else {
				$this->id_asset_type->ViewValue = NULL;
			}
			$this->id_asset_type->ViewCustomAttributes = "";

			// name
			$this->name->ViewValue = $this->name->CurrentValue;
			$this->name->CssStyle = "font-weight: bold;";
			$this->name->ViewCustomAttributes = "";

			// short_description
			$this->short_description->ViewValue = $this->short_description->CurrentValue;
			$this->short_description->ViewCustomAttributes = "";

			// aspect_ratio_1
			$this->aspect_ratio_1->ViewValue = $this->aspect_ratio_1->CurrentValue;
			$this->aspect_ratio_1->ViewCustomAttributes = "";

			// aspect_ratio_2
			$this->aspect_ratio_2->ViewValue = $this->aspect_ratio_2->CurrentValue;
			$this->aspect_ratio_2->ViewCustomAttributes = "";

			// id_extention
			if (strval($this->id_extention->CurrentValue) <> "") {
				$sFilterWrk = "`id`" . ew_SearchString("=", $this->id_extention->CurrentValue, EW_DATATYPE_STRING);
			$sSqlWrk = "SELECT `id`, `name` AS `DispFld`, '' AS `Disp2Fld`, '' AS `Disp3Fld`, '' AS `Disp4Fld` FROM `extention`";
			$sWhereWrk = "";
			if ($sFilterWrk <> "") {
				ew_AddFilter($sWhereWrk, $sFilterWrk);
			}

			// Call Lookup selecting
			$this->Lookup_Selecting($this->id_extention, $sWhereWrk);
			if ($sWhereWrk <> "") $sSqlWrk .= " WHERE " . $sWhereWrk;
				$rswrk = $conn->Execute($sSqlWrk);
				if ($rswrk && !$rswrk->EOF) { // Lookup values found
					$this->id_extention->ViewValue = $rswrk->fields('DispFld');
					$rswrk->Close();
				} else {
					$this->id_extention->ViewValue = $this->id_extention->CurrentValue;
				}
			} else {
				$this->id_extention->ViewValue = NULL;
			}
			$this->id_extention->ViewCustomAttributes = "";

			// size
			$this->size->ViewValue = $this->size->CurrentValue;
			$this->size->ViewCustomAttributes = "";

			// date_create
			$this->date_create->ViewValue = $this->date_create->CurrentValue;
			$this->date_create->ViewValue = ew_FormatDateTime($this->date_create->ViewValue, 9);
			$this->date_create->ViewCustomAttributes = "";

			// date_update
			$this->date_update->ViewValue = $this->date_update->CurrentValue;
			$this->date_update->ViewValue = ew_FormatDateTime($this->date_update->ViewValue, 9);
			$this->date_update->ViewCustomAttributes = "";

			// enabled
			if (strval($this->enabled->CurrentValue) <> "") {
				switch ($this->enabled->CurrentValue) {
					case $this->enabled->FldTagValue(1):
						$this->enabled->ViewValue = $this->enabled->FldTagCaption(1) <> "" ? $this->enabled->FldTagCaption(1) : $this->enabled->CurrentValue;
						break;
					case $this->enabled->FldTagValue(2):
						$this->enabled->ViewValue = $this->enabled->FldTagCaption(2) <> "" ? $this->enabled->FldTagCaption(2) : $this->enabled->CurrentValue;
						break;
					default:
						$this->enabled->ViewValue = $this->enabled->CurrentValue;
				}
			} else {
				$this->enabled->ViewValue = NULL;
			}
			$this->enabled->ViewCustomAttributes = "";

			// file
			if (!ew_Empty($this->file->Upload->DbValue)) {
				$this->file->ViewValue = $this->file->Upload->DbValue;
			} else {
				$this->file->ViewValue = "";
			}
			$this->file->ViewCustomAttributes = "";

			// id
			$this->id->LinkCustomAttributes = "";
			$this->id->HrefValue = "";
			$this->id->TooltipValue = "";

			// id_asset_type
			$this->id_asset_type->LinkCustomAttributes = "";
			$this->id_asset_type->HrefValue = "";
			$this->id_asset_type->TooltipValue = "";

			// name
			$this->name->LinkCustomAttributes = "";
			$this->name->HrefValue = "";
			$this->name->TooltipValue = "";

			// short_description
			$this->short_description->LinkCustomAttributes = "";
			$this->short_description->HrefValue = "";
			$this->short_description->TooltipValue = "";

			// aspect_ratio_1
			$this->aspect_ratio_1->LinkCustomAttributes = "";
			$this->aspect_ratio_1->HrefValue = "";
			$this->aspect_ratio_1->TooltipValue = "";

			// aspect_ratio_2
			$this->aspect_ratio_2->LinkCustomAttributes = "";
			$this->aspect_ratio_2->HrefValue = "";
			$this->aspect_ratio_2->TooltipValue = "";

			// id_extention
			$this->id_extention->LinkCustomAttributes = "";
			$this->id_extention->HrefValue = "";
			$this->id_extention->TooltipValue = "";

			// size
			$this->size->LinkCustomAttributes = "";
			$this->size->HrefValue = "";
			$this->size->TooltipValue = "";

			// enabled
			$this->enabled->LinkCustomAttributes = "";
			$this->enabled->HrefValue = "";
			$this->enabled->TooltipValue = "";

			// file
			$this->file->LinkCustomAttributes = "";
			$this->file->HrefValue = "";
			$this->file->HrefValue2 = $this->file->UploadPath . $this->file->Upload->DbValue;
			$this->file->TooltipValue = "";
		} elseif ($this->RowType == EW_ROWTYPE_ADD) { // Add row

			// id
			$this->id->EditCustomAttributes = "";
			$this->id->EditValue = ew_HtmlEncode($this->id->CurrentValue);
			$this->id->PlaceHolder = ew_HtmlEncode(ew_RemoveHtml($this->id->FldCaption()));

			// id_asset_type
			$this->id_asset_type->EditCustomAttributes = "";
			$sFilterWrk = "";
			$sSqlWrk = "SELECT `id`, `name` AS `DispFld`, '' AS `Disp2Fld`, '' AS `Disp3Fld`, '' AS `Disp4Fld`, '' AS `SelectFilterFld`, '' AS `SelectFilterFld2`, '' AS `SelectFilterFld3`, '' AS `SelectFilterFld4` FROM `asset_type`";
			$sWhereWrk = "";
			if ($sFilterWrk <> "") {
				ew_AddFilter($sWhereWrk, $sFilterWrk);
			}

			// Call Lookup selecting
			$this->Lookup_Selecting($this->id_asset_type, $sWhereWrk);
			if ($sWhereWrk <> "") $sSqlWrk .= " WHERE " . $sWhereWrk;
			$rswrk = $conn->Execute($sSqlWrk);
			$arwrk = ($rswrk) ? $rswrk->GetRows() : array();
			if ($rswrk) $rswrk->Close();
			array_unshift($arwrk, array("", $Language->Phrase("PleaseSelect"), "", "", "", "", "", "", ""));
			$this->id_asset_type->EditValue = $arwrk;

			// name
			$this->name->EditCustomAttributes = "";
			$this->name->EditValue = ew_HtmlEncode($this->name->CurrentValue);
			$this->name->PlaceHolder = ew_HtmlEncode(ew_RemoveHtml($this->name->FldCaption()));

			// short_description
			$this->short_description->EditCustomAttributes = "";
			$this->short_description->EditValue = $this->short_description->CurrentValue;
			$this->short_description->PlaceHolder = ew_HtmlEncode(ew_RemoveHtml($this->short_description->FldCaption()));

			// aspect_ratio_1
			$this->aspect_ratio_1->EditCustomAttributes = "";
			$this->aspect_ratio_1->EditValue = ew_HtmlEncode($this->aspect_ratio_1->CurrentValue);
			$this->aspect_ratio_1->PlaceHolder = ew_HtmlEncode(ew_RemoveHtml($this->aspect_ratio_1->FldCaption()));
			if (strval($this->aspect_ratio_1->EditValue) <> "" && is_numeric($this->aspect_ratio_1->EditValue)) $this->aspect_ratio_1->EditValue = ew_FormatNumber($this->aspect_ratio_1->EditValue, -2, -1, -2, 0);

			// aspect_ratio_2
			$this->aspect_ratio_2->EditCustomAttributes = "";
			$this->aspect_ratio_2->EditValue = ew_HtmlEncode($this->aspect_ratio_2->CurrentValue);
			$this->aspect_ratio_2->PlaceHolder = ew_HtmlEncode(ew_RemoveHtml($this->aspect_ratio_2->FldCaption()));
			if (strval($this->aspect_ratio_2->EditValue) <> "" && is_numeric($this->aspect_ratio_2->EditValue)) $this->aspect_ratio_2->EditValue = ew_FormatNumber($this->aspect_ratio_2->EditValue, -2, -1, -2, 0);

			// id_extention
			$this->id_extention->EditCustomAttributes = "";
			$sFilterWrk = "";
			$sSqlWrk = "SELECT `id`, `name` AS `DispFld`, '' AS `Disp2Fld`, '' AS `Disp3Fld`, '' AS `Disp4Fld`, '' AS `SelectFilterFld`, '' AS `SelectFilterFld2`, '' AS `SelectFilterFld3`, '' AS `SelectFilterFld4` FROM `extention`";
			$sWhereWrk = "";
			if ($sFilterWrk <> "") {
				ew_AddFilter($sWhereWrk, $sFilterWrk);
			}

			// Call Lookup selecting
			$this->Lookup_Selecting($this->id_extention, $sWhereWrk);
			if ($sWhereWrk <> "") $sSqlWrk .= " WHERE " . $sWhereWrk;
			$rswrk = $conn->Execute($sSqlWrk);
			$arwrk = ($rswrk) ? $rswrk->GetRows() : array();
			if ($rswrk) $rswrk->Close();
			array_unshift($arwrk, array("", $Language->Phrase("PleaseSelect"), "", "", "", "", "", "", ""));
			$this->id_extention->EditValue = $arwrk;

			// size
			$this->size->EditCustomAttributes = "";
			$this->size->EditValue = ew_HtmlEncode($this->size->CurrentValue);
			$this->size->PlaceHolder = ew_HtmlEncode(ew_RemoveHtml($this->size->FldCaption()));
			if (strval($this->size->EditValue) <> "" && is_numeric($this->size->EditValue)) $this->size->EditValue = ew_FormatNumber($this->size->EditValue, -2, -1, -2, 0);

			// enabled
			$this->enabled->EditCustomAttributes = "";
			$arwrk = array();
			$arwrk[] = array($this->enabled->FldTagValue(1), $this->enabled->FldTagCaption(1) <> "" ? $this->enabled->FldTagCaption(1) : $this->enabled->FldTagValue(1));
			$arwrk[] = array($this->enabled->FldTagValue(2), $this->enabled->FldTagCaption(2) <> "" ? $this->enabled->FldTagCaption(2) : $this->enabled->FldTagValue(2));
			array_unshift($arwrk, array("", $Language->Phrase("PleaseSelect")));
			$this->enabled->EditValue = $arwrk;

			// file
			$this->file->EditCustomAttributes = "";
			if (!ew_Empty($this->file->Upload->DbValue)) {
				$this->file->EditValue = $this->file->Upload->DbValue;
			} else {
				$this->file->EditValue = "";
			}
			if (($this->CurrentAction == "I" || $this->CurrentAction == "C") && !$this->EventCancelled) ew_RenderUploadField($this->file);

			// Edit refer script
			// id

			$this->id->HrefValue = "";

			// id_asset_type
			$this->id_asset_type->HrefValue = "";

			// name
			$this->name->HrefValue = "";

			// short_description
			$this->short_description->HrefValue = "";

			// aspect_ratio_1
			$this->aspect_ratio_1->HrefValue = "";

			// aspect_ratio_2
			$this->aspect_ratio_2->HrefValue = "";

			// id_extention
			$this->id_extention->HrefValue = "";

			// size
			$this->size->HrefValue = "";

			// enabled
			$this->enabled->HrefValue = "";

			// file
			$this->file->HrefValue = "";
			$this->file->HrefValue2 = $this->file->UploadPath . $this->file->Upload->DbValue;
		}
		if ($this->RowType == EW_ROWTYPE_ADD ||
			$this->RowType == EW_ROWTYPE_EDIT ||
			$this->RowType == EW_ROWTYPE_SEARCH) { // Add / Edit / Search row
			$this->SetupFieldTitles();
		}

		// Call Row Rendered event
		if ($this->RowType <> EW_ROWTYPE_AGGREGATEINIT)
			$this->Row_Rendered();
	}

	// Validate form
	function ValidateForm() {
		global $Language, $gsFormError;

		// Initialize form error message
		$gsFormError = "";

		// Check if validation required
		if (!EW_SERVER_VALIDATE)
			return ($gsFormError == "");
		if (!$this->id->FldIsDetailKey && !is_null($this->id->FormValue) && $this->id->FormValue == "") {
			ew_AddMessage($gsFormError, $Language->Phrase("EnterRequiredField") . " - " . $this->id->FldCaption());
		}
		if (!$this->id_asset_type->FldIsDetailKey && !is_null($this->id_asset_type->FormValue) && $this->id_asset_type->FormValue == "") {
			ew_AddMessage($gsFormError, $Language->Phrase("EnterRequiredField") . " - " . $this->id_asset_type->FldCaption());
		}
		if (!$this->name->FldIsDetailKey && !is_null($this->name->FormValue) && $this->name->FormValue == "") {
			ew_AddMessage($gsFormError, $Language->Phrase("EnterRequiredField") . " - " . $this->name->FldCaption());
		}
		if (!$this->short_description->FldIsDetailKey && !is_null($this->short_description->FormValue) && $this->short_description->FormValue == "") {
			ew_AddMessage($gsFormError, $Language->Phrase("EnterRequiredField") . " - " . $this->short_description->FldCaption());
		}
		if (!$this->aspect_ratio_1->FldIsDetailKey && !is_null($this->aspect_ratio_1->FormValue) && $this->aspect_ratio_1->FormValue == "") {
			ew_AddMessage($gsFormError, $Language->Phrase("EnterRequiredField") . " - " . $this->aspect_ratio_1->FldCaption());
		}
		if (!ew_CheckNumber($this->aspect_ratio_1->FormValue)) {
			ew_AddMessage($gsFormError, $this->aspect_ratio_1->FldErrMsg());
		}
		if (!$this->aspect_ratio_2->FldIsDetailKey && !is_null($this->aspect_ratio_2->FormValue) && $this->aspect_ratio_2->FormValue == "") {
			ew_AddMessage($gsFormError, $Language->Phrase("EnterRequiredField") . " - " . $this->aspect_ratio_2->FldCaption());
		}
		if (!ew_CheckNumber($this->aspect_ratio_2->FormValue)) {
			ew_AddMessage($gsFormError, $this->aspect_ratio_2->FldErrMsg());
		}
		if (!$this->id_extention->FldIsDetailKey && !is_null($this->id_extention->FormValue) && $this->id_extention->FormValue == "") {
			ew_AddMessage($gsFormError, $Language->Phrase("EnterRequiredField") . " - " . $this->id_extention->FldCaption());
		}
		if (!$this->size->FldIsDetailKey && !is_null($this->size->FormValue) && $this->size->FormValue == "") {
			ew_AddMessage($gsFormError, $Language->Phrase("EnterRequiredField") . " - " . $this->size->FldCaption());
		}
		if (!ew_CheckNumber($this->size->FormValue)) {
			ew_AddMessage($gsFormError, $this->size->FldErrMsg());
		}
		if (!$this->enabled->FldIsDetailKey && !is_null($this->enabled->FormValue) && $this->enabled->FormValue == "") {
			ew_AddMessage($gsFormError, $Language->Phrase("EnterRequiredField") . " - " . $this->enabled->FldCaption());
		}

		// Return validate result
		$ValidateForm = ($gsFormError == "");

		// Call Form_CustomValidate event
		$sFormCustomError = "";
		$ValidateForm = $ValidateForm && $this->Form_CustomValidate($sFormCustomError);
		if ($sFormCustomError <> "") {
			ew_AddMessage($gsFormError, $sFormCustomError);
		}
		return $ValidateForm;
	}

	// Add record
	function AddRow($rsold = NULL) {
		global $conn, $Language, $Security;

		// Load db values from rsold
		if ($rsold) {
			$this->LoadDbValues($rsold);
		}
		$rsnew = array();

		// id
		$this->id->SetDbValueDef($rsnew, $this->id->CurrentValue, "", FALSE);

		// id_asset_type
		$this->id_asset_type->SetDbValueDef($rsnew, $this->id_asset_type->CurrentValue, "", FALSE);

		// name
		$this->name->SetDbValueDef($rsnew, $this->name->CurrentValue, "", FALSE);

		// short_description
		$this->short_description->SetDbValueDef($rsnew, $this->short_description->CurrentValue, "", FALSE);

		// aspect_ratio_1
		$this->aspect_ratio_1->SetDbValueDef($rsnew, $this->aspect_ratio_1->CurrentValue, 0, FALSE);

		// aspect_ratio_2
		$this->aspect_ratio_2->SetDbValueDef($rsnew, $this->aspect_ratio_2->CurrentValue, 0, FALSE);

		// id_extention
		$this->id_extention->SetDbValueDef($rsnew, $this->id_extention->CurrentValue, "", FALSE);

		// size
		// enabled

		$this->enabled->SetDbValueDef($rsnew, $this->enabled->CurrentValue, 0, FALSE);

		// file
		if (!$this->file->Upload->KeepFile) {
			if ($this->file->Upload->FileName == "") {
				$rsnew['file'] = NULL;
			} else {
				$rsnew['file'] = $this->file->Upload->FileName;
			}
			$this->size->SetDbValueDef($rsnew, $this->file->Upload->FileSize, 0, FALSE);
		}
		if (!$this->file->Upload->KeepFile) {
			if (!ew_Empty($this->file->Upload->Value)) {
				$rsnew['file'] = ew_UploadFileNameEx(ew_UploadPathEx(TRUE, $this->file->UploadPath), $rsnew['file']); // Get new file name
			}
		}

		// Call Row Inserting event
		$rs = ($rsold == NULL) ? NULL : $rsold->fields;
		$bInsertRow = $this->Row_Inserting($rs, $rsnew);

		// Check if key value entered
		if ($bInsertRow && $this->ValidateKey && $this->id->CurrentValue == "" && $this->id->getSessionValue() == "") {
			$this->setFailureMessage($Language->Phrase("InvalidKeyValue"));
			$bInsertRow = FALSE;
		}

		// Check for duplicate key
		if ($bInsertRow && $this->ValidateKey) {
			$sFilter = $this->KeyFilter();
			$rsChk = $this->LoadRs($sFilter);
			if ($rsChk && !$rsChk->EOF) {
				$sKeyErrMsg = str_replace("%f", $sFilter, $Language->Phrase("DupKey"));
				$this->setFailureMessage($sKeyErrMsg);
				$rsChk->Close();
				$bInsertRow = FALSE;
			}
		}
		if ($bInsertRow) {
			$conn->raiseErrorFn = 'ew_ErrorFn';
			$AddRow = $this->Insert($rsnew);
			$conn->raiseErrorFn = '';
			if ($AddRow) {
				if (!$this->file->Upload->KeepFile) {
					if (!ew_Empty($this->file->Upload->Value)) {
						$this->file->Upload->SaveToFile($this->file->UploadPath, $rsnew['file'], TRUE);
					}
				}
			}
		} else {
			if ($this->getSuccessMessage() <> "" || $this->getFailureMessage() <> "") {

				// Use the message, do nothing
			} elseif ($this->CancelMessage <> "") {
				$this->setFailureMessage($this->CancelMessage);
				$this->CancelMessage = "";
			} else {
				$this->setFailureMessage($Language->Phrase("InsertCancelled"));
			}
			$AddRow = FALSE;
		}

		// Get insert id if necessary
		if ($AddRow) {
		}
		if ($AddRow) {

			// Call Row Inserted event
			$rs = ($rsold == NULL) ? NULL : $rsold->fields;
			$this->Row_Inserted($rs, $rsnew);
		}

		// file
		ew_CleanUploadTempPath($this->file, $this->file->Upload->Index);
		return $AddRow;
	}

	// Set up Breadcrumb
	function SetupBreadcrumb() {
		global $Breadcrumb, $Language;
		$Breadcrumb = new cBreadcrumb();
		$PageCaption = $this->TableCaption();
		$Breadcrumb->Add("list", "<span id=\"ewPageCaption\">" . $PageCaption . "</span>", "assetlist.php", $this->TableVar);
		$PageCaption = ($this->CurrentAction == "C") ? $Language->Phrase("Copy") : $Language->Phrase("Add");
		$Breadcrumb->Add("add", "<span id=\"ewPageCaption\">" . $PageCaption . "</span>", ew_CurrentUrl(), $this->TableVar);
	}

	// Page Load event
	function Page_Load() {

		//echo "Page Load";
	}

	// Page Unload event
	function Page_Unload() {

		//echo "Page Unload";
	}

	// Page Redirecting event
	function Page_Redirecting(&$url) {

		// Example:
		//$url = "your URL";

	}

	// Message Showing event
	// $type = ''|'success'|'failure'|'warning'
	function Message_Showing(&$msg, $type) {
		if ($type == 'success') {

			//$msg = "your success message";
		} elseif ($type == 'failure') {

			//$msg = "your failure message";
		} elseif ($type == 'warning') {

			//$msg = "your warning message";
		} else {

			//$msg = "your message";
		}
	}

	// Page Render event
	function Page_Render() {

		//echo "Page Render";
	}

	// Page Data Rendering event
	function Page_DataRendering(&$header) {

		// Example:
		//$header = "your header";

	}

	// Page Data Rendered event
	function Page_DataRendered(&$footer) {

		// Example:
		//$footer = "your footer";

	}

	// Form Custom Validate event
	function Form_CustomValidate(&$CustomError) {

		// Return error message in CustomError
		return TRUE;
	}
}
?>
<?php ew_Header(FALSE) ?>
<?php

// Create page object
if (!isset($asset_add)) $asset_add = new casset_add();

// Page init
$asset_add->Page_Init();

// Page main
$asset_add->Page_Main();

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$asset_add->Page_Render();
?>
<?php include_once "header.php" ?>
<script type="text/javascript">

// Page object
var asset_add = new ew_Page("asset_add");
asset_add.PageID = "add"; // Page ID
var EW_PAGE_ID = asset_add.PageID; // For backward compatibility

// Form object
var fassetadd = new ew_Form("fassetadd");

// Validate form
fassetadd.Validate = function() {
	if (!this.ValidateRequired)
		return true; // Ignore validation
	var $ = jQuery, fobj = this.GetForm(), $fobj = $(fobj);
	this.PostAutoSuggest();
	if ($fobj.find("#a_confirm").val() == "F")
		return true;
	var elm, felm, uelm, addcnt = 0;
	var $k = $fobj.find("#" + this.FormKeyCountName); // Get key_count
	var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
	var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
	var gridinsert = $fobj.find("#a_list").val() == "gridinsert";
	for (var i = startcnt; i <= rowcnt; i++) {
		var infix = ($k[0]) ? String(i) : "";
		$fobj.data("rowindex", infix);
			elm = this.GetElements("x" + infix + "_id");
			if (elm && !ew_HasValue(elm))
				return this.OnError(elm, ewLanguage.Phrase("EnterRequiredField") + " - <?php echo ew_JsEncode2($asset->id->FldCaption()) ?>");
			elm = this.GetElements("x" + infix + "_id_asset_type");
			if (elm && !ew_HasValue(elm))
				return this.OnError(elm, ewLanguage.Phrase("EnterRequiredField") + " - <?php echo ew_JsEncode2($asset->id_asset_type->FldCaption()) ?>");
			elm = this.GetElements("x" + infix + "_name");
			if (elm && !ew_HasValue(elm))
				return this.OnError(elm, ewLanguage.Phrase("EnterRequiredField") + " - <?php echo ew_JsEncode2($asset->name->FldCaption()) ?>");
			elm = this.GetElements("x" + infix + "_short_description");
			if (elm && !ew_HasValue(elm))
				return this.OnError(elm, ewLanguage.Phrase("EnterRequiredField") + " - <?php echo ew_JsEncode2($asset->short_description->FldCaption()) ?>");
			elm = this.GetElements("x" + infix + "_aspect_ratio_1");
			if (elm && !ew_HasValue(elm))
				return this.OnError(elm, ewLanguage.Phrase("EnterRequiredField") + " - <?php echo ew_JsEncode2($asset->aspect_ratio_1->FldCaption()) ?>");
			elm = this.GetElements("x" + infix + "_aspect_ratio_1");
			if (elm && !ew_CheckNumber(elm.value))
				return this.OnError(elm, "<?php echo ew_JsEncode2($asset->aspect_ratio_1->FldErrMsg()) ?>");
			elm = this.GetElements("x" + infix + "_aspect_ratio_2");
			if (elm && !ew_HasValue(elm))
				return this.OnError(elm, ewLanguage.Phrase("EnterRequiredField") + " - <?php echo ew_JsEncode2($asset->aspect_ratio_2->FldCaption()) ?>");
			elm = this.GetElements("x" + infix + "_aspect_ratio_2");
			if (elm && !ew_CheckNumber(elm.value))
				return this.OnError(elm, "<?php echo ew_JsEncode2($asset->aspect_ratio_2->FldErrMsg()) ?>");
			elm = this.GetElements("x" + infix + "_id_extention");
			if (elm && !ew_HasValue(elm))
				return this.OnError(elm, ewLanguage.Phrase("EnterRequiredField") + " - <?php echo ew_JsEncode2($asset->id_extention->FldCaption()) ?>");
			elm = this.GetElements("x" + infix + "_size");
			if (elm && !ew_HasValue(elm))
				return this.OnError(elm, ewLanguage.Phrase("EnterRequiredField") + " - <?php echo ew_JsEncode2($asset->size->FldCaption()) ?>");
			elm = this.GetElements("x" + infix + "_size");
			if (elm && !ew_CheckNumber(elm.value))
				return this.OnError(elm, "<?php echo ew_JsEncode2($asset->size->FldErrMsg()) ?>");
			elm = this.GetElements("x" + infix + "_enabled");
			if (elm && !ew_HasValue(elm))
				return this.OnError(elm, ewLanguage.Phrase("EnterRequiredField") + " - <?php echo ew_JsEncode2($asset->enabled->FldCaption()) ?>");

			// Set up row object
			ew_ElementsToRow(fobj);

			// Fire Form_CustomValidate event
			if (!this.Form_CustomValidate(fobj))
				return false;
	}

	// Process detail forms
	var dfs = $fobj.find("input[name='detailpage']").get();
	for (var i = 0; i < dfs.length; i++) {
		var df = dfs[i], val = df.value;
		if (val && ewForms[val])
			if (!ewForms[val].Validate())
				return false;
	}
	return true;
}

// Form_CustomValidate event
fassetadd.Form_CustomValidate = 
 function(fobj) { // DO NOT CHANGE THIS LINE!

 	// Your custom validation code here, return false if invalid. 
 	return true;
 }

// Use JavaScript validation or not
<?php if (EW_CLIENT_VALIDATE) { ?>
fassetadd.ValidateRequired = true;
<?php } else { ?>
fassetadd.ValidateRequired = false; 
<?php } ?>

// Dynamic selection lists
fassetadd.Lists["x_id_asset_type"] = {"LinkField":"x_id","Ajax":null,"AutoFill":false,"DisplayFields":["x_name","","",""],"ParentFields":[],"FilterFields":[],"Options":[]};
fassetadd.Lists["x_id_extention"] = {"LinkField":"x_id","Ajax":null,"AutoFill":false,"DisplayFields":["x_name","","",""],"ParentFields":[],"FilterFields":[],"Options":[]};

// Form object for search
</script>
<script type="text/javascript">

// Write your client script here, no need to add script tags.
</script>
<?php $Breadcrumb->Render(); ?>
<?php $asset_add->ShowPageHeader(); ?>
<?php
$asset_add->ShowMessage();
?>
<form name="fassetadd" id="fassetadd" class="ewForm form-horizontal" action="<?php echo ew_CurrentPage() ?>" method="post">
<input type="hidden" name="t" value="asset">
<input type="hidden" name="a_add" id="a_add" value="A">
<table cellspacing="0" class="ewGrid"><tr><td>
<table id="tbl_assetadd" class="table table-bordered table-striped">
<?php if ($asset->id->Visible) { // id ?>
	<tr id="r_id">
		<td><span id="elh_asset_id"><?php echo $asset->id->FldCaption() ?><?php echo $Language->Phrase("FieldRequiredIndicator") ?></span></td>
		<td<?php echo $asset->id->CellAttributes() ?>>
<span id="el_asset_id" class="control-group">
<input type="text" data-field="x_id" name="x_id" id="x_id" size="30" maxlength="32" placeholder="<?php echo $asset->id->PlaceHolder ?>" value="<?php echo $asset->id->EditValue ?>"<?php echo $asset->id->EditAttributes() ?>>
</span>
<?php echo $asset->id->CustomMsg ?></td>
	</tr>
<?php } ?>
<?php if ($asset->id_asset_type->Visible) { // id_asset_type ?>
	<tr id="r_id_asset_type">
		<td><span id="elh_asset_id_asset_type"><?php echo $asset->id_asset_type->FldCaption() ?><?php echo $Language->Phrase("FieldRequiredIndicator") ?></span></td>
		<td<?php echo $asset->id_asset_type->CellAttributes() ?>>
<span id="el_asset_id_asset_type" class="control-group">
<select data-field="x_id_asset_type" id="x_id_asset_type" name="x_id_asset_type"<?php echo $asset->id_asset_type->EditAttributes() ?>>
<?php
if (is_array($asset->id_asset_type->EditValue)) {
	$arwrk = $asset->id_asset_type->EditValue;
	$rowswrk = count($arwrk);
	$emptywrk = TRUE;
	for ($rowcntwrk = 0; $rowcntwrk < $rowswrk; $rowcntwrk++) {
		$selwrk = (strval($asset->id_asset_type->CurrentValue) == strval($arwrk[$rowcntwrk][0])) ? " selected=\"selected\"" : "";
		if ($selwrk <> "") $emptywrk = FALSE;
?>
<option value="<?php echo ew_HtmlEncode($arwrk[$rowcntwrk][0]) ?>"<?php echo $selwrk ?>>
<?php echo $arwrk[$rowcntwrk][1] ?>
</option>
<?php
	}
}
?>
</select>
<script type="text/javascript">
fassetadd.Lists["x_id_asset_type"].Options = <?php echo (is_array($asset->id_asset_type->EditValue)) ? ew_ArrayToJson($asset->id_asset_type->EditValue, 1) : "[]" ?>;
</script>
</span>
<?php echo $asset->id_asset_type->CustomMsg ?></td>
	</tr>
<?php } ?>
<?php if ($asset->name->Visible) { // name ?>
	<tr id="r_name">
		<td><span id="elh_asset_name"><?php echo $asset->name->FldCaption() ?><?php echo $Language->Phrase("FieldRequiredIndicator") ?></span></td>
		<td<?php echo $asset->name->CellAttributes() ?>>
<span id="el_asset_name" class="control-group">
<input type="text" data-field="x_name" name="x_name" id="x_name" size="30" maxlength="50" placeholder="<?php echo $asset->name->PlaceHolder ?>" value="<?php echo $asset->name->EditValue ?>"<?php echo $asset->name->EditAttributes() ?>>
</span>
<?php echo $asset->name->CustomMsg ?></td>
	</tr>
<?php } ?>
<?php if ($asset->short_description->Visible) { // short_description ?>
	<tr id="r_short_description">
		<td><span id="elh_asset_short_description"><?php echo $asset->short_description->FldCaption() ?><?php echo $Language->Phrase("FieldRequiredIndicator") ?></span></td>
		<td<?php echo $asset->short_description->CellAttributes() ?>>
<span id="el_asset_short_description" class="control-group">
<textarea data-field="x_short_description" name="x_short_description" id="x_short_description" cols="35" rows="4" placeholder="<?php echo $asset->short_description->PlaceHolder ?>"<?php echo $asset->short_description->EditAttributes() ?>><?php echo $asset->short_description->EditValue ?></textarea>
</span>
<?php echo $asset->short_description->CustomMsg ?></td>
	</tr>
<?php } ?>
<?php if ($asset->aspect_ratio_1->Visible) { // aspect_ratio_1 ?>
	<tr id="r_aspect_ratio_1">
		<td><span id="elh_asset_aspect_ratio_1"><?php echo $asset->aspect_ratio_1->FldCaption() ?><?php echo $Language->Phrase("FieldRequiredIndicator") ?></span></td>
		<td<?php echo $asset->aspect_ratio_1->CellAttributes() ?>>
<span id="el_asset_aspect_ratio_1" class="control-group">
<input type="text" data-field="x_aspect_ratio_1" name="x_aspect_ratio_1" id="x_aspect_ratio_1" size="30" placeholder="<?php echo $asset->aspect_ratio_1->PlaceHolder ?>" value="<?php echo $asset->aspect_ratio_1->EditValue ?>"<?php echo $asset->aspect_ratio_1->EditAttributes() ?>>
</span>
<?php echo $asset->aspect_ratio_1->CustomMsg ?></td>
	</tr>
<?php } ?>
<?php if ($asset->aspect_ratio_2->Visible) { // aspect_ratio_2 ?>
	<tr id="r_aspect_ratio_2">
		<td><span id="elh_asset_aspect_ratio_2"><?php echo $asset->aspect_ratio_2->FldCaption() ?><?php echo $Language->Phrase("FieldRequiredIndicator") ?></span></td>
		<td<?php echo $asset->aspect_ratio_2->CellAttributes() ?>>
<span id="el_asset_aspect_ratio_2" class="control-group">
<input type="text" data-field="x_aspect_ratio_2" name="x_aspect_ratio_2" id="x_aspect_ratio_2" size="30" placeholder="<?php echo $asset->aspect_ratio_2->PlaceHolder ?>" value="<?php echo $asset->aspect_ratio_2->EditValue ?>"<?php echo $asset->aspect_ratio_2->EditAttributes() ?>>
</span>
<?php echo $asset->aspect_ratio_2->CustomMsg ?></td>
	</tr>
<?php } ?>
<?php if ($asset->id_extention->Visible) { // id_extention ?>
	<tr id="r_id_extention">
		<td><span id="elh_asset_id_extention"><?php echo $asset->id_extention->FldCaption() ?><?php echo $Language->Phrase("FieldRequiredIndicator") ?></span></td>
		<td<?php echo $asset->id_extention->CellAttributes() ?>>
<span id="el_asset_id_extention" class="control-group">
<select data-field="x_id_extention" id="x_id_extention" name="x_id_extention"<?php echo $asset->id_extention->EditAttributes() ?>>
<?php
if (is_array($asset->id_extention->EditValue)) {
	$arwrk = $asset->id_extention->EditValue;
	$rowswrk = count($arwrk);
	$emptywrk = TRUE;
	for ($rowcntwrk = 0; $rowcntwrk < $rowswrk; $rowcntwrk++) {
		$selwrk = (strval($asset->id_extention->CurrentValue) == strval($arwrk[$rowcntwrk][0])) ? " selected=\"selected\"" : "";
		if ($selwrk <> "") $emptywrk = FALSE;
?>
<option value="<?php echo ew_HtmlEncode($arwrk[$rowcntwrk][0]) ?>"<?php echo $selwrk ?>>
<?php echo $arwrk[$rowcntwrk][1] ?>
</option>
<?php
	}
}
?>
</select>
<script type="text/javascript">
fassetadd.Lists["x_id_extention"].Options = <?php echo (is_array($asset->id_extention->EditValue)) ? ew_ArrayToJson($asset->id_extention->EditValue, 1) : "[]" ?>;
</script>
</span>
<?php echo $asset->id_extention->CustomMsg ?></td>
	</tr>
<?php } ?>
<?php if ($asset->size->Visible) { // size ?>
	<tr id="r_size">
		<td><span id="elh_asset_size"><?php echo $asset->size->FldCaption() ?><?php echo $Language->Phrase("FieldRequiredIndicator") ?></span></td>
		<td<?php echo $asset->size->CellAttributes() ?>>
<span id="el_asset_size" class="control-group">
<input type="text" data-field="x_size" name="x_size" id="x_size" size="30" placeholder="<?php echo $asset->size->PlaceHolder ?>" value="<?php echo $asset->size->EditValue ?>"<?php echo $asset->size->EditAttributes() ?>>
</span>
<?php echo $asset->size->CustomMsg ?></td>
	</tr>
<?php } ?>
<?php if ($asset->enabled->Visible) { // enabled ?>
	<tr id="r_enabled">
		<td><span id="elh_asset_enabled"><?php echo $asset->enabled->FldCaption() ?><?php echo $Language->Phrase("FieldRequiredIndicator") ?></span></td>
		<td<?php echo $asset->enabled->CellAttributes() ?>>
<span id="el_asset_enabled" class="control-group">
<select data-field="x_enabled" id="x_enabled" name="x_enabled"<?php echo $asset->enabled->EditAttributes() ?>>
<?php
if (is_array($asset->enabled->EditValue)) {
	$arwrk = $asset->enabled->EditValue;
	$rowswrk = count($arwrk);
	$emptywrk = TRUE;
	for ($rowcntwrk = 0; $rowcntwrk < $rowswrk; $rowcntwrk++) {
		$selwrk = (strval($asset->enabled->CurrentValue) == strval($arwrk[$rowcntwrk][0])) ? " selected=\"selected\"" : "";
		if ($selwrk <> "") $emptywrk = FALSE;
?>
<option value="<?php echo ew_HtmlEncode($arwrk[$rowcntwrk][0]) ?>"<?php echo $selwrk ?>>
<?php echo $arwrk[$rowcntwrk][1] ?>
</option>
<?php
	}
}
?>
</select>
</span>
<?php echo $asset->enabled->CustomMsg ?></td>
	</tr>
<?php } ?>
<?php if ($asset->file->Visible) { // file ?>
	<tr id="r_file">
		<td><span id="elh_asset_file"><?php echo $asset->file->FldCaption() ?></span></td>
		<td<?php echo $asset->file->CellAttributes() ?>>
<span id="el_asset_file" class="control-group">
<span id="fd_x_file">
<span class="btn btn-small fileinput-button">
	<span><?php echo $Language->Phrase("ChooseFile") ?></span>
	<input type="file" data-field="x_file" name="x_file" id="x_file">
</span>
<input type="hidden" name="fn_x_file" id= "fn_x_file" value="<?php echo $asset->file->Upload->FileName ?>">
<input type="hidden" name="fa_x_file" id= "fa_x_file" value="0">
<input type="hidden" name="fs_x_file" id= "fs_x_file" value="200">
</span>
<table id="ft_x_file" class="table table-condensed pull-left ewUploadTable"><tbody class="files"></tbody></table>
</span>
<?php echo $asset->file->CustomMsg ?></td>
	</tr>
<?php } ?>
</table>
</td></tr></table>
<button class="btn btn-primary ewButton" name="btnAction" id="btnAction" type="submit"><?php echo $Language->Phrase("AddBtn") ?></button>
</form>
<script type="text/javascript">
fassetadd.Init();
<?php if (EW_MOBILE_REFLOW && ew_IsMobile()) { ?>
ew_Reflow();
<?php } ?>
</script>
<?php
$asset_add->ShowPageFooter();
if (EW_DEBUG_ENABLED)
	echo ew_DebugMsg();
?>
<script type="text/javascript">

// Write your table-specific startup script here
// document.write("page loaded");

</script>
<?php include_once "footer.php" ?>
<?php
$asset_add->Page_Terminate();
?>
