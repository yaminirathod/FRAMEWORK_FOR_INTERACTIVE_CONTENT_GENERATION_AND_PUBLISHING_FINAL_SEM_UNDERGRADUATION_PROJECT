<?php

require_once('../config/masterDatabaseAccess.php');
require_once('../customScript/masterCustomScript.php');

$_POST = sanitize($_POST);

if (isset($_POST['submit'])) {

    $old_password= "";
    $new_password= "";
    $new_passwordRe= "";

    if (isset($_POST['old_password'])) {
        $old_password = $_POST['old_password'];
    }
    if (isset($_POST['new_password'])) {
        $new_password = $_POST['new_password'];
    }
    if (isset($_POST['new_passwordRe'])) {
        $new_passwordRe = $_POST['new_passwordRe'];
    }

    if(checkPassword($old_password,30) == 1){
        $status = base64_encode("Old password is invalid.");
        $target = "2";
        $kind = base64_encode("4");
        header('location: ../router.php?status=' . $status . '&target=' . $target . '&kind=' . $kind);
    } else if(checkPassword($new_password,30) == 1){
        $status = base64_encode("New password is invalid.");
        $target = "2";
        $kind = base64_encode("4");
        header('location: ../router.php?status=' . $status . '&target=' . $target . '&kind=' . $kind);
    }else if(checkPassword($new_passwordRe,30) == 1){
        $status = base64_encode("New password retyped is invalid.");
        $target = "2";
        $kind = base64_encode("4");
        header('location: ../router.php?status=' . $status . '&target=' . $target . '&kind=' . $kind);
    } else if(compareValues($new_password,$new_passwordRe)){
        $status = base64_encode("New passwords does not match.");
        $target = "2";
        $kind = base64_encode("4");
        header('location: ../router.php?status=' . $status . '&target=' . $target . '&kind=' . $kind);
    } else {
	
		$user_id = getSession("user_id");
		$password = ORM::for_table('login')->select('password')->where('id_user', $user_id)->find_one();
	    $DBPassword = $password->password;
		
		$salt = ORM::for_table('salt')->where('id_user',$user_id)->find_one();
		$masterSalt1 = $salt->salt_1;
		$masterSalt2 = $salt->salt_2;
		
		$tempPassword = passwordEncrypt($old_password, $masterSalt1, $masterSalt2);
	
	
        if($DBPassword != $tempPassword){
			$status = base64_encode("Old password is invalid.");
			$target = "2";
			$kind = base64_encode("4");
            header('location: ../router.php?status=' . $status . '&target=' . $target . '&kind=' . $kind);
		}else{

            $new_passwordTemp = passwordEncrypt($new_password, $masterSalt1, $masterSalt2);
			
			$sqll = "UPDATE login SET password='$new_passwordTemp' WHERE id_user = '$user_id'";
			
			//$sqll = ORM::for_table('login')->update('password')->where('user_id', $user_id)->find_one();
			//$password->password;
			
            $status = base64_encode("Password is changed successfully");
            $target = "2";
            $kind = base64_encode("1");
//            header('location: ../router.php?status=' . $status . '&target=' . $target . '&kind=' . $kind);
        }
    }
} else {
    $status = base64_encode("This request did not originated from source form");
    $target = "2";
    $kind = base64_encode("4");
//    header('location: ../router.php?status=' . $status . '&target=' . $target . '&kind=' . $kind);
}
?>

