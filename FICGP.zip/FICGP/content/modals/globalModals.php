<div class="hardScreen"></div>

<div class="modalContainer" id="changePasswordAdminModal" style="z-index:20;">
    <div class="modalTitle">
        <div class="modalTitleText"> Change Password</div>
        <div class="modalCloseButton" onclick="closeThisModal()"><a href="#"> <span
                    class="glyphicon glyphicon-trash"></span> Discard</a></div>
    </div>
    <div class="loading">
        <img class="loadingImage" src="img/loading.gif"/> Loading
    </div>
    <div class="modalBody">
    </div>
</div>

<script type="text/javascript">
    function changePasswordAdminModal() {
        $(".hardScreen").fadeIn(100, function () {
            $('#changePasswordAdminModal').animate({top: "0%"}, 250, function () {
                $("#changePasswordAdminModal .loading").show(0);
                $("#changePasswordAdminModal .modalBody").load("content/forms/changePasswordAdmin.php", function () {
                    $("#changePasswordAdminModal .loading").fadeOut(250, function () {
                        $("#changePasswordAdminModal .modalBody").fadeIn(250);
                    });
                });
            })
        })
    }
</script>

<div class="modalContainer" id="changePasswordUserModal" style="z-index:20;">
    <div class="modalTitle">
        <div class="modalTitleText"> Change Password</div>
        <div class="modalCloseButton" onclick="closeThisModal()"><a href="#"> <span
                    class="glyphicon glyphicon-trash"></span> Discard</a></div>
    </div>
    <div class="loading">
        <img class="loadingImage" src="img/loading.gif"/> Loading
    </div>
    <div class="modalBody">
    </div>
</div>

<script type="text/javascript">
    function changePasswordUserModal() {
        $(".hardScreen").fadeIn(100, function () {
            $('#changePasswordUserModal').animate({top: "0%"}, 250, function () {
                $("#changePasswordUserModal .loading").show(0);
                $("#changePasswordUserModal .modalBody").load("content/forms/changePasswordUser.php", function () {
                    $("#changePasswordUserModal .loading").fadeOut(250, function () {
                        $("#changePasswordUserModal .modalBody").fadeIn(250);
                    });
                });
            })
        })
    }
</script>