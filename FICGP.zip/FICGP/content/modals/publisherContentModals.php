<div class="hardScreen"></div>

<div class="modalContainer" id="addAssetModal" style="width: 95%;left: 2.5%;height: 90%;">
    <div class="modalTitle">
        <div class="modalTitleText"> Add Asset</div>
        <div class="modalCloseButton" onclick="closeThisModal()"><a href="#"> <span
                    class="glyphicon glyphicon-trash"></span> Discard</a></div>
    </div>
    <div class="modalBody" style="max-height: 90%;"></div>
</div>

<script type="text/javascript">
    function addAssetModal() {
        $(".hardScreen").fadeIn(100, function () {
            $('#addAssetModal').animate({top: "0%"}, 250, function () {
                $("#addAssetModal .modalBody").load("content/forms/addAsset.php");
            })
        })
    }
</script>