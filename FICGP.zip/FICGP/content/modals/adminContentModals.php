<div class="hardScreen"></div>

<div class="modalContainer" id="editUserTypeModal">
    <div class="modalTitle">
        <div class="modalTitleText"> Edit User Type</div>
        <div class="modalCloseButton" onclick="closeThisModal()"><a href="#"> <span
                    class="glyphicon glyphicon-trash"></span> Discard</a></div>
    </div>
    <div class="loading">
        <img class="loadingImage" src="img/loading.gif"/> Loading
    </div>
    <div class="modalBody">
    </div>
</div>

<script type="text/javascript">
    function editUserTypeModal(id) {
        $(".hardScreen").fadeIn(100, function () {
            $('#editUserTypeModal').animate({top: "0%"}, 250, function () {
                $("#editUserTypeModal .loading").show(0);
                $("#editUserTypeModal .modalBody").load("content/forms/editUserType.php?id=" + id, function () {
                    $("#editUserTypeModal .loading").fadeOut(250, function () {
                        $("#editUserTypeModal .modalBody").fadeIn(250);
                    });
                });
            })
        })
    }
</script>

<div class="modalContainer" id="editPageModal">
    <div class="modalTitle">
        <div class="modalTitleText"> Edit Page</div>
        <div class="modalCloseButton" onclick="closeThisModal()"><a href="#"> <span
                    class="glyphicon glyphicon-trash"></span> Discard</a></div>
    </div>
    <div class="loading">
        <img class="loadingImage" src="img/loading.gif"/> Loading
    </div>
    <div class="modalBody">
    </div>
</div>

<script type="text/javascript">
    function editPageModal(id) {
        $(".hardScreen").fadeIn(100, function () {
            $('#editPageModal').animate({top: "0%"}, 250, function () {
                $("#editPageModal .loading").show(0);
                $("#editPageModal .modalBody").load("content/forms/editPage.php?id=" + id, function () {
                    $("#editPageModal .loading").fadeOut(250, function () {
                        $("#editPageModal .modalBody").fadeIn(250);
                    });
                });
            })
        })
    }
</script>

<div class="modalContainer" id="addUserTypeModal">
    <div class="modalTitle">
        <div class="modalTitleText"> Add User Type</div>
        <div class="modalCloseButton" onclick="closeThisModal()"><a href="#"> <span
                    class="glyphicon glyphicon-trash"></span> Discard</a></div>
    </div>
    <div class="loading">
        <img class="loadingImage" src="img/loading.gif"/> Loading
    </div>
    <div class="modalBody">
    </div>
</div>

<script type="text/javascript">
    function addUserTypeModal() {
        $(".hardScreen").fadeIn(100, function () {
            $('#addUserTypeModal').animate({top: "0%"}, 250, function () {
                $("#addUserTypeModal .loading").show(0);
                $("#addUserTypeModal .modalBody").load("content/forms/addUserType.php", function () {
                    $("#addUserTypeModal .loading").fadeOut(250, function () {
                        $("#addUserTypeModal .modalBody").fadeIn(250);
                    });
                });
            })
        })
    }
</script>


<div class="modalContainer" id="addModuleModal">
    <div class="modalTitle">
        <div class="modalTitleText"> Add Module</div>
        <div class="modalCloseButton" onclick="closeThisModal()"><a href="#"> <span
                    class="glyphicon glyphicon-trash"></span> Discard</a></div>
    </div>
    <div class="loading">
        <img class="loadingImage" src="img/loading.gif"/> Loading
    </div>
    <div class="modalBody">
    </div>
</div>

<script type="text/javascript">
    function addModuleModal() {
        $(".hardScreen").fadeIn(100, function () {
            $('#addModuleModal').animate({top: "0%"}, 250, function () {
                $("#addModuleModal .loading").show(0);
                $("#addModuleModal .modalBody").load("content/forms/addModule.php", function () {
                    $("#addModuleModal .loading").fadeOut(250, function () {
                        $("#addModuleModal .modalBody").fadeIn(250);
                    });
                });
            })
        })
    }
</script>


<div class="modalContainer" id="addPageModal">
    <div class="modalTitle">
        <div class="modalTitleText"> Add Page</div>
        <div class="modalCloseButton" onclick="closeThisModal()"><a href="#"> <span
                    class="glyphicon glyphicon-trash"></span> Discard</a></div>
    </div>
    <div class="loading">
        <img class="loadingImage" src="img/loading.gif"/> Loading
    </div>
    <div class="modalBody">
    </div>
</div>

<script type="text/javascript">
    function addPageModal() {
        $(".hardScreen").fadeIn(100, function () {
            $('#addPageModal').animate({top: "0%"}, 250, function () {
                $("#addPageModal .loading").show(0);
                $("#addPageModal .modalBody").load("content/forms/addPage.php", function () {
                    $("#addPageModal .loading").fadeOut(250, function () {
                        $("#addPageModal .modalBody").fadeIn(250);
                    });
                });
            })
        })
    }
</script>


<div class="modalContainer" id="addUserModal">
    <div class="modalTitle">
        <div class="modalTitleText"> Add User</div>
        <div class="modalCloseButton" onclick="closeThisModal()"><a href="#"> <span
                    class="glyphicon glyphicon-trash"></span> Discard</a></div>
    </div>
    <div class="loading">
        <img class="loadingImage" src="img/loading.gif"/> Loading
    </div>
    <div class="modalBody">
    </div>
</div>

<script type="text/javascript">
    function addUserModal() {
        $(".hardScreen").fadeIn(100, function () {
            $('#addUserModal').animate({top: "0%"}, 250, function () {
                $("#addUserModal .loading").show(0);
                $("#addUserModal .modalBody").load("content/forms/addUser.php?back=" + curActiveMicroContainer, function () {
                    $("#addUserModal .loading").fadeOut(250, function () {
                        $("#addUserModal .modalBody").fadeIn(250);
                    });
                });
            })
        })
    }
</script>

<div class="modalContainer" id="editUserModal">
    <div class="modalTitle">
        <div class="modalTitleText"> Edit User</div>
        <div class="modalCloseButton" onclick="closeThisModal()"><a href="#"> <span
                    class="glyphicon glyphicon-trash"></span> Discard</a></div>
    </div>
    <div class="loading">
        <img class="loadingImage" src="img/loading.gif"/> Loading
    </div>
    <div class="modalBody">
    </div>
</div>

<script type="text/javascript">
    function editUserModal(id) {
        $(".hardScreen").fadeIn(100, function () {
            $('#editUserModal').animate({top: "0%"}, 250, function () {
                $("#editUserModal .loading").show(0);
                $("#editUserModal .modalBody").load("content/forms/editUser.php?id=" + id + "&back=" + curActiveMicroTab, function () {
                    $("#editUserModal .loading").fadeOut(250, function () {
                        $("#editUserModal .modalBody").fadeIn(250);
                    });
                });
            })
        })
    }
</script>

