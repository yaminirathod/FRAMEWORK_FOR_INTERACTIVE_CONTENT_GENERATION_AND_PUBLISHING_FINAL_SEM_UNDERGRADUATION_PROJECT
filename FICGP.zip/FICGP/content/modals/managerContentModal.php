<div class="hardScreen"></div>

<div class="modalContainer" id="addAssetTypeModal">
    <div class="modalTitle">
        <div class="modalTitleText"> Add Asset Type</div>
        <div class="modalCloseButton" onclick="closeThisModal()"><a href="#"> <span
                    class="glyphicon glyphicon-trash"></span> Discard</a></div>
    </div>
    <div class="loading">
        <img class="loadingImage" src="img/loading.gif"/> Loading
    </div>
    <div class="modalBody">
    </div>
</div>

<script type="text/javascript">
    function addAssetTypeModal() {
        $(".hardScreen").fadeIn(100, function () {
            $('#addAssetTypeModal').animate({top: "0%"}, 250, function () {
                $("#addAssetTypeModal .loading").show(0);
                $("#addAssetTypeModal .modalBody").load("content/forms/addAssetType.php", function () {
                    $("#addAssetTypeModal .loading").fadeOut(250, function () {
                        $("#addAssetTypeModal .modalBody").fadeIn(250);
                    });
                });
            })
        })
    }
</script>

<div class="modalContainer" id="editAssetTypeModal">
    <div class="modalTitle">
        <div class="modalTitleText"> Edit Asset Type</div>
        <div class="modalCloseButton" onclick="closeThisModal()"><a href="#"> <span
                    class="glyphicon glyphicon-trash"></span> Discard</a></div>
    </div>
    <div class="loading">
        <img class="loadingImage" src="img/loading.gif"/> Loading
    </div>
    <div class="modalBody">
    </div>
</div>

<script type="text/javascript">
    function editAssetTypeModal(id) {
        $(".hardScreen").fadeIn(100, function () {
            $('#editAssetTypeModal').animate({top: "0%"}, 250, function () {
                $("#editAssetTypeModal .loading").show(0);
                $("#editAssetTypeModal .modalBody").load("content/forms/editAssetType.php?id=" + id, function () {
                    $("#editAssetTypeModal .loading").fadeOut(250, function () {
                        $("#editAssetTypeModal .modalBody").fadeIn(250);
                    });
                });
            })
        })
    }
</script>