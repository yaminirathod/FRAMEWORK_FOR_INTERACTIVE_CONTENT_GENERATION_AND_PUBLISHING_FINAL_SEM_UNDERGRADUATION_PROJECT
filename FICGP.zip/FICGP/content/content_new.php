<?php $page_url = "new.php"; ?><?php require_once('config/masterDatabaseAccess.php'); ?>
<?php require_once('customScript/masterCustomScript.php'); ?>
<div class="widescreen">
    <?php require_once('header/loadSideBar.php'); ?>
    <div id="mainContent">
        <div id="content">
            <div class="container">
                <div class="row">
                        <?php
                            $module_associations = ORM::for_table('module_association')->raw_query("SELECT page.id,
                              module.id AS id1,
                              module.name AS name1,
                              module.url,
                              module.enabled,
                              page.url AS url1,
                              module_association.enabled
                            FROM module_association
                              INNER JOIN page ON page.id = module_association.id_page
                              INNER JOIN module ON module.id = module_association.id_module
                            WHERE page.url = '$page_url' and module_association.enabled = 1 and module.enabled = 1 ORDER BY name1")->find_many();
                            $numbers = $module_associations->count();
                            if ($numbers == 0) {
                                
                            }
                            else{
                                ?>
                                <div class="col-xs-4" >
                                    <div class="myTabs" style="height:650px;overflow:auto;">
                                        <?php
                                        $i=1;
                                        foreach ($module_associations as $module_association) {
                                        ?>
                                            <div id="myTab<?= $i ?>" onclick="performTab(<?= $i ?>);" class="myTab" targetContainer="container<?= $i ?>">
                                                <span class="glyphicon glyphicon-hand-right"></span> <?= $module_association->name1 ?>
                                            </div>
                                        <?php
                                        $i++;
                                        }
                                        ?>
                                    </div>
                                </div>

                                <div class="col-xs-8">
                                    <div class="myTabContainers">
                                        <?php
                                        $i=1;
                                        foreach ($module_associations as $module_association) {
                                        ?>
                                            <div id="myContainer<?= $i ?>" class="myContainer">
                                                <div class="panel_title"><h5><b><?= $module_association->name1 ?></b></h5></div>
                                                <iframe src="content/modules/<?= $module_association->url ?>/index.php" style="height:600px;float:left;posision:relative;"></iframe>
                                            </div>
                                        <?php
                                        $i++;
                                        }
                                        ?>
                                    </div>
                                </div>

                    <?php
                            }
                        ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

<div class="boxscreen">
    Box screen
</div>

<div class="mobile">
    Mobile screen
</div>