<script type="text/javascript">
    ul = null;
    errorFlag = 0;

    function validate() {
        ul = null;

        if (checkPassword("old_password", addUser.old_password.value, 30) == 1) {
            errorFlag = 1;
        }

        if (checkPassword("new_password", addUser.new_password.value, 30) == 1) {
            errorFlag = 1;
        }

        if (checkPassword("new_passwordRe", addUser.new_passwordRe.value, 30) == 1) {
            errorFlag = 1;
        }

        if (compareValues("new_password", "new_passwordRe", addUser.new_password.value, addUser.new_passwordRe.value) == 1) {
            errorFlag = 1;
        }

        if (errorFlag == 1) {
            $("#formAlertContainer").empty();
            ul.appendTo("#formAlertContainer")
            showFormAlertBox();
            return false;
        } else {
            return true;
        }
    }
</script>

<?php require_once('../forms/formAlertData.php'); ?>

<form method="post" name="changePassword" onSubmit="return validate();" action="content/changePasswordUser.php">

    <div class="form-group">

        <div class="form-group">
            <div class="col-lg-3">
                <label for="first_name">Old Password</label>
            </div>
            <div class="col-lg-9">
                <input type="password" name="old_password" id="old_password" class="form-control" placeholder="Enter old password">
            </div>
        </div>

        <div class="form-group">
            <div class="col-lg-3">
                <label for="Password">New Password</label>
            </div>
            <div class="col-lg-9">
                <input type="password" name="new_password" id="new_password" class="form-control" placeholder="Enter new password">
            </div>
        </div>

        <div class="form-group">
            <div class="col-lg-3">
                <label for="Password">New Password Retype</label>
            </div>
            <div class="col-lg-9">
                <input type="password" name="new_passwordRe" id="new_passwordRe" class="form-control" placeholder="Retype new password">
            </div>
        </div>

        <button name="submit" type="submit" class="btn btn-default" style="border-radius: 0px;">
            <span class="glyphicon glyphicon-plus"></span> Change Password
        </button>
</form>
<hr/>
<b>Form filling guidelines</b><br/><br/>
<ul>
    <li><b>Old Password : </b>Allowed Values : 0-9, a-z, A-Z, White Spaces, Spacial Characters ; Maximum Length : 30
    </li>
    <li><b>New Password : </b>Allowed Values : 0-9, a-z, A-Z, White Spaces, Spacial Characters ; Maximum Length : 30
    </li>
    <li><b>New Password Retype: </b>Allowed Values : 0-9, a-z, A-Z, White Spaces, Spacial Characters ; Maximum Length : 30
    </li>
</ul>
