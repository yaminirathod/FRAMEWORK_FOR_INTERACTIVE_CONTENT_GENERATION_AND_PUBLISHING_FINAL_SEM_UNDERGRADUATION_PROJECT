<div id="formScreen"></div>

<div id="formAlertBox">
    <div id="formAlertBoxTitle">
        <div id="formTitleText">
            Please correct these error(s)
        </div>
        <a href="#" onclick="closeFormAlertBox();">
            <div id="formCloseButton">
                <span class="glyphicon glyphicon-trash"></span> Discard
            </div>
        </a>
    </div>
    <div id="formAlertContainer">
    </div>
</div>