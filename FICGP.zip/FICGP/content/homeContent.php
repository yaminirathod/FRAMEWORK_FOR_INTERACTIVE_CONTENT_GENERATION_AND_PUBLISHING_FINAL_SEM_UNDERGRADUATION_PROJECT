<?php require_once('config/masterDatabaseAccess.php'); ?>
<?php require_once('customScript/masterCustomScript.php'); ?>

<div class="widescreen">
    <?php require_once('header/loadSideBar.php'); ?>

    <div id="mainContent">
        <div id="mainContenTitle">
            <div id="titleText">
                Welcome
            </div>
            <?php require_once('content/showMessage.php'); ?>
        </div>
        <div id="content">
            <div class="container">

                <div class="row">
                    <div class="col-lg-12">
                        <form class="form-signin" method="post" action="customScript/checkUserlogin.php">
                            <h2 class="form-signin-heading">Please sign in</h2>
                            <hr>
                            <label for="email" class="sr-only">Email address</label>
                            <input name="email" id="email" class="form-control" placeholder="Email address or Username"
                                   required
                                   autofocus
                                   style="margin-bottom: 10px;">
                            <label for="password" class="sr-only">Password</label>
                            <input name="password" id="password" type="password" class="form-control"
                                   placeholder="Password"
                                   required>
                            <hr>
                            <button class="btn btn-lg btn-primary btn-block" type="submit">
                                <span class="glyphicon glyphicon-log-in"></span>&nbsp;&nbsp;Sign me in
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="boxscreen">
    Box screen
</div>

<div class="mobile">
    Mobile screen
</div>