<?php

require_once('../customScript/masterCustomScript.php');

$_POST = sanitize($_POST);

if (isset($_POST['submit'])) {

    require_once('../config/randomString.php');

    $myfile = fopen("../config/randomString.php", "r") or die("Unable to open file!");
    $dump = fread($myfile, filesize("../config/randomString.php"));
    fclose($myfile);

    $old_password= "";
    $new_password= "";
    $new_passwordRe= "";

    if (isset($_POST['old_password'])) {
        $old_password = $_POST['old_password'];
    }
    if (isset($_POST['new_password'])) {
        $new_password = $_POST['new_password'];
    }
    if (isset($_POST['new_passwordRe'])) {
        $new_passwordRe = $_POST['new_passwordRe'];
    }

    if(checkPassword($old_password,30) == 1){
        $status = base64_encode("Old password is invalid.");
        $target = "2";
        $kind = base64_encode("4");
        header('location: ../router.php?status=' . $status . '&target=' . $target . '&kind=' . $kind);
    } else if(checkPassword($new_password,30) == 1){
        $status = base64_encode("New password is invalid.");
        $target = "2";
        $kind = base64_encode("4");
        header('location: ../router.php?status=' . $status . '&target=' . $target . '&kind=' . $kind);
    }else if(checkPassword($new_passwordRe,30) == 1){
        $status = base64_encode("New password retyped is invalid.");
        $target = "2";
        $kind = base64_encode("4");
        header('location: ../router.php?status=' . $status . '&target=' . $target . '&kind=' . $kind);
    } else if(compareValues($new_password,$new_passwordRe)){
        $status = base64_encode("New passwords does not match.");
        $target = "2";
        $kind = base64_encode("4");
        header('location: ../router.php?status=' . $status . '&target=' . $target . '&kind=' . $kind);
    } else {
        if($dump != $old_password){
            $status = base64_encode("Provided password does not match old one");
            $target = "2";
            $kind = base64_encode("4");
            header('location: ../router.php?status=' . $status . '&target=' . $target . '&kind=' . $kind);
        }else{

            $myfile1 = fopen("../config/randomString.php", "w") or die("Unable to open file!");
            fwrite($myfile1,$new_password,strlen($new_password));
            fclose($myfile1);

            $status = base64_encode("Password is changed successfully");
            $target = "2";
            $kind = base64_encode("1");
            header('location: ../router.php?status=' . $status . '&target=' . $target . '&kind=' . $kind);
        }
    }
} else {
    $status = base64_encode("This request did not originated from source form");
    $target = "2";
    $kind = base64_encode("4");
    header('location: ../router.php?status=' . $status . '&target=' . $target . '&kind=' . $kind);
}
?>

