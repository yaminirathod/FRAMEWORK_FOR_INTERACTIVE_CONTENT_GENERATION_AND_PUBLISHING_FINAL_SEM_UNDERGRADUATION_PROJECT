<?php

$sponsers = ORM::for_table('sponser')->order_by_asc('name')->find_many();
$numbers = $sponsers->count();

if ($numbers == 0) {
    ?>
    <div class="panel panel-warning">
        <div class="panel-heading">No Sponsers in system</div>
        <div class="panel-body">
            <p>It seems that you have not created any sponsers in the system. and also blah blah blah.</p>
        </div>
    </div><?php
} else {
    ?>
    <?php
    foreach ($sponsers as $sponser) {
    }
}
?>