<?php

$assetTypes = ORM::for_table('asset_type')->order_by_asc('name')->find_many();
$numbers = $assetTypes->count();

if ($numbers == 0) {
    ?>
    <div class="panel panel-warning">
        <div class="panel-heading">No Asset types in system</div>
        <div class="panel-body">
            <p>It seems that you have not created any asset types in the system. and also blah blah blah.</p>
        </div>
    </div><?php
} else {
    ?>
    <div class="row">
        <div class="col-lg-3" style="padding: 0px 10px 0px 0px;">
            <div class="mySubTabs">
                <?php
                $counter = 0;
                foreach ($assetTypes as $assetType) {
                    $counter++;
                    if ($assetType->enabled == 1) {
                        ?>
                        <div id="mySubTab<?= $counter ?>" onclick="performSubTab(<?= $counter ?>,1);" class="mySubTab"
                             targetContainer="container1">
                            <span
                                class="glyphicon glyphicon-hand-right"></span>&nbsp;&nbsp;<?= $assetType->name ?>
                        </div>
                    <?php
                    }
                }
                ?>
            </div>
        </div>

        <div class="col-lg-9" style="margin-left: -15px;">
            <div class="myTabSubContainers">
                <?php
                $counter = 0;
                foreach ($assetTypes as $assetType) {
                    $counter++;
                    if ($assetType->enabled == 1) {
                        ?>
                        <div id="mySubContainer<?= $counter ?>" class="mySubContainer">
                            <div class="panel_title"><h5><b><?= $assetType->name ?> Overview</b>
                                    | <?= $assetType->size ?> Mb
                                </h5>

                                <?php
                                /*
                                $extentions = explode(",", $assetType->accepted_extention);
                                foreach ($extentions as $extention) {
                                    ?>
                                    <div class="extentionContainer">
                                        <div class="extentionHeading">
                                            <?= $extention ?>
                                        </div>
                                    </div>
                                <?php
                                }
                                */
                                ?>
                            </div>

                            <?php
                            $assets = ORM::for_table('asset')->where('id_asset_type', $assetType->id)->order_by_asc('name')->find_many();
                            $numbersAsset = $assets->count();

                            if ($numbersAsset == 0) {
                                ?>
                                <div class="panel panel-warning" style="margin-top: 32px;">
                                    <div class="panel-heading">No Assets in this asset type</div>
                                    <div class="panel-body">
                                        <p>It seems that you have not uploaded any assets in this category. and also
                                            blah blah blah.</p>
                                    </div>
                                </div>
                            <?php
                            } else {
                            }
                            ?>

                        </div>
                    <?php
                    }
                }
                ?>
            </div>
        </div>
    </div>
<?php
}
?>