<?php

$publishers = ORM::for_table('publisher')->order_by_asc('name')->find_many();
$numbers = $publishers->count();

if ($numbers == 0) {
    ?>
    <div class="panel panel-warning">
        <div class="panel-heading">No Publishers in system</div>
        <div class="panel-body">
            <p>It seems that you have not created any Publishers in the system. and also blah blah blah.</p>
        </div>
    </div><?php
} else {
    ?>
    <?php
    foreach ($publishers as $publisher) {

    }
}
?>