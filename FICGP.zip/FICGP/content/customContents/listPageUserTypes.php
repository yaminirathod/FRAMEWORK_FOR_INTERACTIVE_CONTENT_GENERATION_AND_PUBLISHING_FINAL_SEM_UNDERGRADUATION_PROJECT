<?php

$userTypes = ORM::for_table('user_type')->order_by_asc('name')->find_many();
$numbers = $userTypes->count();

if ($numbers == 0) {
    ?>
    <div class="panel panel-warning">
        <div class="panel-heading">No user types in system</div>
        <div class="panel-body">
            <p>It seems that you have not created any user types in the system. and also blah blah blah.</p>
        </div>
    </div><?php
} else {
    ?>
    <div class="row" style="margin-left: -15px;">
        <div class="col-xs-12">
            <div class="myMicroTabs">

                <?php
                $i = 0;
                foreach ($userTypes as $userType) {
                    ?>
                    <div id="myMicroTab_3_<?= (++$i) ?>" onclick="performMicroTab(<?= ($i) ?>,3,2);" class="myMicroTab"
                         targetContainer="container<?= ($i) ?>">
                        <?= $userType->name ?>
                    </div>
                <?php
                }
                ?>
            </div>
        </div>
    </div>

    <div class="row" style="margin-top: 50px;margin-left: -15px;">
        <div class="col-xs-12">

            <div class="myMicroTabContainers">

                <?php
                $i = 0;
                $backCount = 0;
                foreach ($userTypes as $userType) {
                    $backCount++;
                    ?>
                    <div id="myMicroContainer_3_<?= (++$i) ?>" class="myMicroContainer">
                        <?php
                        $counter++;
                        $pages = ORM::for_table('page')->order_by_asc('name')->find_many();
                        $pageNumbers = $pages->count();
                        if ($pageNumbers > 0) {
                            $pageAssociations = ORM::for_table('page_association')->where('id_user_type', $userType->id)->find_many();
                            $pageAssociationNumbers = $pageAssociations->count();
                            if ($pageAssociationNumbers > 0) {
                                foreach ($pages as $page) {

                                    foreach ($pageAssociations as $pageAssociation) {

                                        if ($page->id == $pageAssociation->id_page) {
                                            ?>
                                            <div class="col-lg-4" style="padding:5px 5px 5px 5px;">
                                                <div class="pageAssociationContainer">
                                                    <div class="pageAssociationName"><?= $page->name ?></div>
                                                    <div class="pageAssiciationFooter">
                                                        <div class="pageAssociationStatus">
                                                            <?php
                                                            if ($pageAssociation->enabled == 0) {
                                                                echo "disabled";
                                                            } else {
                                                                echo "enabled";
                                                            }
                                                            ?>
                                                        </div>
                                                        <?php
                                                        if ($pageAssociation->enabled == 0) {
                                                            ?>
                                                            <a href="content/pageAssociate.php?page_associate_id=<?= $pageAssociation->id_page ?>&operation=1&back=<?= $counter ?>">
                                                                <div class="pageAssociationButton">
                                                                    Add
                                                                </div>
                                                            </a>
                                                        <?php
                                                        } else {
                                                            ?>
                                                            <a href="content/pageAssociate.php?page_associate_id=<?= $pageAssociation->id_page ?>&operation=0&back=<?= $counter ?>">
                                                                <div class="pageAssociationButton">
                                                                    Remove
                                                                </div>
                                                            </a>
                                                        <?php
                                                        }
                                                        ?>

                                                    </div>

                                                </div>
                                            </div>
                                        <?php
                                        }
                                    }
                                }
                            }
                        } else {
                            ?>
                            <div class="panel panel-warning">
                                <div class="panel-heading">No pages in system</div>
                                <div class="panel-body">
                                    <p>It seems that you have not created any pages in the system. and also blah
                                        blah blah.</p>
                                </div>
                            </div>
                        <?php
                        }
                        ?>
                    </div>
                <?php
                }
                ?>
            </div>
        </div>
    </div>

<?php
}
?>

<script type="text/javascript">
    function openThisModal(id) {
        userTypeId = id;
        $('#editUserTypeModal').modal('show');
    }
</script>