<?php
require_once('customScript/checkSession.php');
checkThisPage("approver.php");
?>
<?php require_once('header/essentials.php'); ?>
<?php require_once('content/approverContent.php'); ?>
<?php require_once('footer/footer.php'); ?>